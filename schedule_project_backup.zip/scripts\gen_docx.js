const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType, PageBreak,
        LevelFormat, Header, Footer, PageNumber } = require('docx');

const border = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const borders = { top: border, bottom: border, left: border, right: border };
const cellMargins = { top: 60, bottom: 60, left: 100, right: 100 };
const headerBorder = { style: BorderStyle.SINGLE, size: 1, color: "2C3E50" };
const headerBorders = { top: headerBorder, bottom: headerBorder, left: headerBorder, right: headerBorder };

function headerCell(text, width) {
  return new TableCell({
    borders: headerBorders,
    width: { size: width, type: WidthType.DXA },
    shading: { fill: "2C3E50", type: ShadingType.CLEAR },
    margins: cellMargins,
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text, bold: true, color: "FFFFFF", font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" }, size: 20 })]
    })]
  });
}

function dataCell(text, width, opts = {}) {
  return new TableCell({
    borders,
    width: { size: width, type: WidthType.DXA },
    shading: opts.shading ? { fill: opts.shading, type: ShadingType.CLEAR } : undefined,
    margins: cellMargins,
    children: [new Paragraph({
      alignment: opts.center ? AlignmentType.CENTER : AlignmentType.LEFT,
      children: [new TextRun({
        text,
        font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
        size: 20,
        bold: opts.bold || false,
        color: opts.color || "333333"
      })]
    })]
  });
}

function p(text, opts = {}) {
  return new Paragraph({
    spacing: { after: 120 },
    children: [new TextRun({
      text,
      font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
      size: 22,
      bold: opts.bold || false,
      color: opts.color || "333333"
    })]
  });
}

function heading1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 200 },
    children: [new TextRun({
      text,
      font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
      size: 34, bold: true, color: "2C3E50"
    })]
  });
}

function heading2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 160 },
    children: [new TextRun({
      text,
      font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
      size: 28, bold: true, color: "2C3E50"
    })]
  });
}

function heading3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 200, after: 120 },
    children: [new TextRun({
      text,
      font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
      size: 24, bold: true, color: "34495E"
    })]
  });
}

function bullet(text) {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    spacing: { after: 80 },
    children: [new TextRun({
      text,
      font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
      size: 21, color: "555555"
    })]
  });
}

function makeTable(headers, rows, widths) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    columnWidths: widths,
    rows: [
      new TableRow({
        cantSplit: true,
        children: headers.map((h, i) => headerCell(h, widths[i]))
      }),
      ...rows.map(row =>
        new TableRow({
          cantSplit: true,
          children: row.map((cell, i) =>
            typeof cell === 'object' ? dataCell(cell.text, widths[i], cell.opts || { center: true }) : dataCell(cell, widths[i], { center: true })
          )
        })
      )
    ]
  });
}

// ======================== BUILD DOCUMENT ========================

const doc = new Document({
  styles: {
    default: {
      document: {
        run: {
          font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
          size: 22
        }
      }
    },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 34, bold: true, font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" }, color: "2C3E50" },
        paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0, keepNext: false, keepLines: false } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" }, color: "2C3E50" },
        paragraph: { spacing: { before: 280, after: 160 }, outlineLevel: 1, keepNext: false, keepLines: false } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 24, bold: true, font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" }, color: "34495E" },
        paragraph: { spacing: { before: 200, after: 120 }, outlineLevel: 2, keepNext: false, keepLines: false } },
    ]
  },
  numbering: {
    config: [
      { reference: "bullets",
        levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838 }, // A4
        margin: { top: 1440, right: 1200, bottom: 1440, left: 1200 }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({
            text: "课程表排课系统 - 产品文档",
            font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
            size: 16, color: "999999"
          })]
        })]
      })
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: "第 ", font: { ascii: "Arial", eastAsia: "Microsoft YaHei" }, size: 18, color: "999999" }),
            new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "999999" }),
            new TextRun({ text: " 页", font: { ascii: "Arial", eastAsia: "Microsoft YaHei" }, size: 18, color: "999999" })
          ]
        })]
      })
    },
    children: [

      // ====== TITLE PAGE ======
      new Paragraph({ spacing: { before: 2400 }, children: [] }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 200 },
        children: [new TextRun({
          text: "课程表排课系统",
          font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
          size: 52, bold: true, color: "2C3E50"
        })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 120 },
        children: [new TextRun({
          text: "Suno Scheduling",
          font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
          size: 36, color: "C8963E"
        })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 600 },
        children: [new TextRun({
          text: "产品文档",
          font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
          size: 30, color: "7F8C8D"
        })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new TextRun({
          text: "高中教师工作安排与课程表智能编排系统",
          font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
          size: 22, color: "95A5A6"
        })]
      }),
      new Paragraph({ children: [new PageBreak()] }),

      // ====== CH1 ======
      heading1("一、系统概述"),
      p("课程表排课系统（Suno Scheduling）是一个纯前端的高中课程表自动编排系统，用于高中年级的教师工作安排与课程表智能生成。系统采用 HTML/CSS/JS 技术栈，零后端依赖，所有功能在一个 HTML 文件中完成。"),
      p(""),

      makeTable(
        ["项目", "说明"],
        [
          ["系统名称", "课程表排课系统（Suno Scheduling）"],
          ["目标用户", "高中年级教务管理人员"],
          ["技术架构", "纯前端单页应用（HTML/CSS/JS）"],
          ["设计风格", "IE1F 风格（深蓝 + 金色配色）"],
          ["部署方式", "单个 HTML 文件，浏览器直接打开即可使用"],
        ],
        [2500, 6860]
      ),

      // ====== CH2 ======
      heading1("二、核心功能模块"),

      heading2("2.1 全局配置（导航栏）"),
      p("导航栏集中提供系统级操作入口，包含以下功能："),
      makeTable(
        ["功能", "说明"],
        [
          ["班级总数设置", "数字输入框，设定全校班级总数量"],
          ["每天节数设置", "数字输入框，支持 1-12 节课灵活配置"],
          ["智能排课", "一键自动排课按钮，触发核心排课算法"],
          ["撤销/重做", "支持 Ctrl+Z/Ctrl+Y 快捷键，最多保留 50 步历史"],
          ["清空数据", "一键重置所有配置与课程安排数据"],
          ["导出 Excel", "将生成的课程表导出为 .xlsx 文件"],
          ["导入 Excel", "从教师工作安排 Excel 导入数据，自动解析"],
        ],
        [2200, 7160]
      ),

      heading2("2.2 班级种类配置"),
      p("系统支持创建多种班级类型（以下简称\"班种\"），适应高中常见的分班教学模式。典型班种包括：普通班、合格班、走班、体通等。"),

      heading3("2.2.1 班种配置项"),
      makeTable(
        ["配置项", "说明"],
        [
          ["班种名称", "自定义编辑，如\"普通班\"\"走班\"等"],
          ["模式", "常规 / 走班（走班课程独立排课）"],
          ["周类型", "每周 / 单周 / 双周 / 单双周"],
          ["固定课时数", "该班种每周固定的课时数量"],
          ["允许时段", "勾选第几节课可排此班种的课，空则全部允许"],
        ],
        [2200, 7160]
      ),

      p("管理操作：可随时添加新的班种；可删除已有班种（系统至少保留一个）；所有班种配置均支持动态编辑。"),

      heading2("2.3 班会设置"),
      p("系统支持为每个班级设置固定的班会时间，排课时自动预留该时段。"),
      makeTable(
        ["配置项", "说明"],
        [
          ["开启/关闭", "控制是否启用班会功能"],
          ["星期", "班会所在的星期几（周一至周五）"],
          ["节次", "班会在当天的第几节课"],
        ],
        [2200, 7160]
      ),
      p("排课时，班会时段自动排除不参与排课，课程表中对应位置显示\"班会\"标记。"),

      heading2("2.4 科目与教师管理"),

      heading3("2.4.1 预设科目"),
      p("系统预置以下科目，每个科目配有专属颜色标识：语文、数学、英语、物理、化学、生物、历史、地理、政治、体育、通用。"),

      heading3("2.4.2 四维课时体系"),
      makeTable(
        ["维度", "说明"],
        [
          ["固定课时", "每周固定安排上课的课时数量"],
          ["单周课时", "仅在单周安排上课的课时数量"],
          ["双周课时", "仅在双周安排上课的课时数量"],
          ["待定课时", "尚未指定单周或双周的课时数量"],
        ],
        [2200, 7160]
      ),
      p("互斥规则：单/双周课时与待定课时互斥——填写单周或双周课时后，待定课时自动清零；反之亦然。"),

      heading3("2.4.3 教师配置项"),
      makeTable(
        ["配置项", "说明"],
        [
          ["姓名", "教师的完整姓名"],
          ["简称", "排课时显示用的简短名称（如\"泽\"\"华\"）"],
          ["任教班级分配", "按班种分组分配班级，指定教师任教的具体班级"],
        ],
        [2200, 7160]
      ),

      heading2("2.5 教师配置弹窗"),
      bullet("全局班级池：顶部展示所有班级号码，方便参考对照"),
      bullet("班种分区：按班种分组展示班级列表，每个分区提供\"将班级添加至当前班种\"按钮"),
      bullet("课时分配表格：底部以表格形式展示，每班占一行，可编辑各项课时数据"),
      bullet("辅助功能：均分课时（将总课时平均分配到各任教班级）；手动调整课时（逐班精细调整各项课时数值）"),

      heading2("2.6 智能排课算法"),

      heading3("2.6.1 算法策略"),
      bullet("多轮重启策略：最多尝试 12 次排课，取最优结果"),
      bullet("贪心排课：以班级为单位进行贪心排课"),
      bullet("三阶段渐进式约束：从严格到宽松逐级放宽约束条件"),

      heading3("2.6.2 三个阶段"),
      makeTable(
        ["阶段", "教师每天上限", "每科每天上限", "说明"],
        [
          ["阶段1", "≤4 节", "≤2 节", "严格约束，优先保证排课质量"],
          ["阶段2", "≤5 节", "≤3 节", "适当放宽，提高排课成功率"],
          ["阶段3", "≤6 节", "≤4 节", "最低约束，兜底保证任务完成"],
        ],
        [1600, 2000, 2000, 3760]
      ),

      heading3("2.6.3 约束规则"),
      bullet("教师冲突：同一教师同一时段不可安排多个班级"),
      bullet("班会预留：班会时段不安排课程"),
      bullet("时段限制：遵守班种配置的允许时段约束"),
      bullet("周期共享：单周/双周课时可在同一时段的相反周期共享"),
      bullet("走班独立安排：走班课程在所有常规课程排完后独立进行安排"),
      bullet("班级数推断：系统优先从教师数据中推断实际班级数，仅在数据不可用时回退全局配置"),

      heading2("2.7 课程表渲染"),
      p("课程表采用横向五天（周一至周五）、纵向按节次展开的经典布局。每个工作日下方分为各班列和一个走班列。单元格以\"科目名+教师简称\"格式展示（如\"语文泽\"\"数学华\"），左侧彩色边框标识科目，右上角标注单/双周。课程表底部显示已排课时数和课时覆盖率。"),

      makeTable(
        ["元素", "说明"],
        [
          ["课程标识", "科目名 + 教师简称（如\"语文泽\"\"数学华\"）"],
          ["科目颜色", "左侧彩色边框标识科目，颜色与科目预设一致"],
          ["周期标签", "单周课时右上角标注\"单\"，双周标注\"双\""],
          ["班会标记", "班会时段合并显示\"班会\""],
          ["午休分隔", "上午下午之间以分隔线区分"],
        ],
        [2200, 7160]
      ),

      heading2("2.8 Excel 导入功能"),
      bullet("支持双区域 Excel：如左右两栏的教师工作安排表"),
      bullet("自动识别表头，跳过产假/退休行，自动继承科目名称"),
      bullet("解析班级范围：支持\"1-5班\"\"走班3\"等格式，自动展开"),
      bullet("自动过滤合格性考班级，不纳入排课"),
      bullet("导入预览弹窗：展示解析数据、支持修改、支持同步班级总数"),
      bullet("自动将总课时均分到各班"),

      heading2("2.9 Excel 导出功能"),
      p("基于 SheetJS 库将生成的课程表导出为 .xlsx 文件，包含完整课程表表格结构、科目颜色标识、单/双周标签和班会标记。"),

      heading2("2.10 数据持久化"),
      p("系统使用浏览器 localStorage 自动保存所有状态数据，刷新页面后数据不丢失。系统具备向后兼容的数据迁移能力：旧格式 classHours（数字）自动转换为新四维课时格式（固定/单周/双周/待定对象）；旧格式 classTypeAssignments 兼容读取并转换为新数据结构。"),

      // ====== CH3 ======
      heading1("三、技术架构"),

      heading2("3.1 技术栈"),
      makeTable(
        ["层级", "技术"],
        [
          ["前端框架", "原生 HTML/CSS/JS（无框架依赖）"],
          ["表格导出", "SheetJS（xlsx.js）"],
          ["数据持久化", "浏览器 localStorage"],
          ["撤销/重做", "基于 JSON 快照的栈实现"],
          ["部署", "单文件，浏览器直接打开"],
        ],
        [2500, 6860]
      ),

      heading2("3.2 架构特点"),
      bullet("零后端依赖：所有逻辑在浏览器端完成"),
      bullet("单文件架构：一个 HTML 文件包含全部 CSS 和 JS，便于分发和维护"),
      bullet("响应式布局：适配不同屏幕尺寸，支持面板折叠"),
      bullet("IE1F 设计风格：深蓝色主色调搭配金色点缀，专业教务管理视觉风格"),

      heading2("3.3 撤销/重做机制"),
      bullet("基于 JSON 快照栈实现"),
      bullet("最大快照数：50 步"),
      bullet("快捷键支持：Ctrl+Z（撤销）/ Ctrl+Y（重做）"),
      bullet("每次修改操作前自动保存当前状态快照"),

      // ====== CH4 ======
      heading1("四、功能模块全景图"),
      p("课程表排课系统 (Suno Scheduling)"),

      makeTable(
        ["模块", "子功能"],
        [
          [{ text: "导航栏（全局配置）", opts: { bold: true, color: "2C3E50" } }, "班级总数 / 每天节数 | 智能排课 | 撤销/重做 | 清空数据 | 导入/导出 Excel"],
          [{ text: "班级种类配置", opts: { bold: true, color: "2C3E50" } }, "班种增删改 | 模式（常规/走班） | 周类型 | 固定课时 / 允许时段"],
          [{ text: "班会设置", opts: { bold: true, color: "2C3E50" } }, "开关控制 | 星期 + 节次配置"],
          [{ text: "科目与教师管理", opts: { bold: true, color: "2C3E50" } }, "科目标签页（11个预设科目） | 教师列表 | 四维课时体系"],
          [{ text: "教师配置弹窗", opts: { bold: true, color: "2C3E50" } }, "全局班级池 | 班种分区班级分配 | 课时分配表（均分/手动）"],
          [{ text: "智能排课算法", opts: { bold: true, color: "2C3E50" } }, "多轮重启策略（12次） | 三阶段渐进约束 | 独立走班排课"],
          [{ text: "课程表渲染", opts: { bold: true, color: "2C3E50" } }, "5天×N节表格 | 科目颜色+教师简称 | 单/双周标签 | 统计信息"],
          [{ text: "数据持久化", opts: { bold: true, color: "2C3E50" } }, "localStorage 自动保存 | 旧格式兼容迁移"],
        ],
        [2800, 6560]
      ),

      // ====== CH5 ======
      heading1("五、使用流程"),

      makeTable(
        ["步骤", "操作", "说明"],
        [
          ["1", "导入 Excel / 手动录入", "从教师工作安排 Excel 导入或手动添加教师"],
          ["2", "配置班级种类", "设置班种名称、模式、周类型、课时等"],
          ["3", "配置班会时间", "可选步骤，设置班会时间和节次"],
          ["4", "分配班级与课时", "为每位教师分配任教班级并设置课时"],
          ["5", "智能排课", "点击按钮一键生成课程表"],
          ["6", "导出课程表", "查看调整课程表后导出为 Excel"],
        ],
        [1200, 3200, 4960]
      ),

    ]
  }]
});

Packer.toBuffer(doc).then(buf => {
  const outPath = 'C:\\Users\\sl315\\AppData\\Roaming\\TRAE SOLO CN\\ModularData\\ai-agent\\work-mode-projects\\6a54eed2739a715a6232c34e\\课程表排课系统_产品文档.docx';
  fs.writeFileSync(outPath, buf);
  console.log('OK: ' + outPath);
});
