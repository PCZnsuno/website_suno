# -*- coding: utf-8 -*-
import openpyxl
import os
import json
from collections import defaultdict, Counter

FILE_PATH = r"c:\Users\sl315\.trae-cn\attachments\6a54eed2739a715a6232c351\c8327b87-f461-4348-9873-d307a3cdecac_95b77871-fbe8-4cfa-87bd-c9865cc218fe_2526第一学期高二级课程表.xlsx"

print("="*100)
print("课程表Excel文件详细分析报告")
print("="*100)

# 检查文件是否存在
if not os.path.exists(FILE_PATH):
    print(f"文件不存在: {FILE_PATH}")
    exit(1)

print(f"\n文件大小: {os.path.getsize(FILE_PATH)} bytes")

wb = openpyxl.load_workbook(FILE_PATH, data_only=True)

# ============================================================
# 1. Sheet基本信息
# ============================================================
print("\n" + "="*100)
print("【1】Sheet基本信息")
print("="*100)
print(f"Sheet总数: {len(wb.sheetnames)}")
for i, name in enumerate(wb.sheetnames):
    ws = wb[name]
    print(f"  Sheet {i+1}: '{name}' | 行数={ws.max_row} | 列数={ws.max_column}")

# ============================================================
# 2 & 3. 每个sheet的前15行完整内容 + 单元格格式分析
# ============================================================
for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
    print("\n" + "="*100)
    print(f"【2&3】Sheet: '{sheet_name}' 前15行完整内容")
    print("="*100)
    
    # 打印列号头部
    header_row = "行号  |"
    for c in range(1, min(ws.max_column+1, 30)):
        header_row += f"  列{c:2d}  |"
    print(header_row)
    print("-" * len(header_row))
    
    for r in range(1, min(16, ws.max_row+1)):
        row_str = f"{r:4d}  |"
        for c in range(1, min(ws.max_column+1, 30)):
            cell = ws.cell(row=r, column=c)
            val = cell.value
            if val is None:
                row_str += "  None |"
            else:
                # 将换行符用[BR]标记，便于观察格式
                display = str(val).replace('\n', '[BR]').replace('\r', '[CR]')
                if len(display) > 7:
                    display = display[:5] + ".."
                row_str += f" {display:6s}|"
        print(row_str)

# ============================================================
# 4. 检查单双周配对 - 搜索包含换行或双课程的单元格
# ============================================================
print("\n" + "="*100)
print("【4】单双周/双课程配对检查（含换行符的单元格）")
print("="*100)

for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
    found_count = 0
    print(f"\n--- Sheet: '{sheet_name}' ---")
    for r in range(1, ws.max_row+1):
        for c in range(1, ws.max_column+1):
            cell = ws.cell(row=r, column=c)
            val = cell.value
            if val is not None and isinstance(val, str) and ('\n' in val or '\r' in val):
                found_count += 1
                display = str(val).replace('\n', '[BR]').replace('\r', '[CR]')
                print(f"  单元格({r},{c}): '{display}'")
    print(f"  共找到 {found_count} 个含换行符的单元格")

# ============================================================
# 5. 分析午休行、上午下午课时
# ============================================================
print("\n" + "="*100)
print("【5】午休行和上下午课时分析")
print("="*100)

for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
    print(f"\n--- Sheet: '{sheet_name}' ---")
    noon_found = False
    for r in range(1, ws.max_row+1):
        row_text = ""
        for c in range(1, min(ws.max_column+1, 10)):
            val = ws.cell(row=r, column=c).value
            if val is not None:
                row_text += str(val) + " "
        if any(keyword in row_text for keyword in ['午休', '午', '午餐', '休息']):
            noon_found = True
            print(f"  午休行可能在第{r}行: {row_text.strip()}")
        # 也查看第一列中包含"第X节"的
        val1 = ws.cell(row=r, column=1).value
        if val1 is not None:
            val1_str = str(val1).strip()
            if '节' in val1_str or '第' in val1_str or '上午' in val1_str or '下午' in val1_str:
                print(f"  第{r}行第1列: '{val1_str}'")
    if not noon_found:
        print("  未找到明显的午休标记行")

# ============================================================
# 6. 合并单元格检查
# ============================================================
print("\n" + "="*100)
print("【8】合并单元格检查")
print("="*100)

for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
    merged = ws.merged_cells.ranges
    print(f"\n--- Sheet: '{sheet_name}' ---")
    print(f"  合并单元格总数: {len(merged)}")
    if len(merged) > 0:
        for i, merge_range in enumerate(merged):
            if i < 50:  # 最多显示50个
                # 获取合并区域的值
                min_row, min_col = merge_range.min_row, merge_range.min_col
                val = ws.cell(row=min_row, column=min_col).value
                print(f"  [{i+1}] {merge_range} (值='{val}')")
            elif i == 50:
                print(f"  ... 还有更多合并单元格，共{len(merged)}个")

# ============================================================
# 9. 完整视觉布局描述 - 读取所有数据
# ============================================================
print("\n" + "="*100)
print("【9】完整视觉布局 - 每个Sheet全量数据（前30行，前20列）")
print("="*100)

for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
    max_r = min(30, ws.max_row)
    max_c = min(20, ws.max_column)
    
    print(f"\n--- Sheet: '{sheet_name}' (显示{max_r}行 x {max_c}列) ---")
    
    # 计算每列最大宽度
    col_widths = {}
    for c in range(1, max_c+1):
        max_w = 4  # 列号宽度
        for r in range(1, max_r+1):
            val = ws.cell(row=r, column=c).value
            if val is not None:
                display = str(val).replace('\n', '/')
                max_w = max(max_w, min(len(display)+2, 16))
        col_widths[c] = max_w
    
    # 打印表头
    header = f"{'行':>4s} |"
    for c in range(1, max_c+1):
        header += f"{'列'+str(c):^{col_widths[c]}s}|"
    print(header)
    print("-" * len(header))
    
    for r in range(1, max_r+1):
        row_str = f"{r:4d} |"
        for c in range(1, max_c+1):
            val = ws.cell(row=r, column=c).value
            if val is None:
                display = ""
            else:
                display = str(val).replace('\n', '/').replace('\r', '')
                if len(display) > col_widths[c]-1:
                    display = display[:col_widths[c]-3] + "..."
            row_str += f"{display:^{col_widths[c]}s}|"
        print(row_str)

# ============================================================
# 6. 课程分布统计（尝试识别课程表结构）
# ============================================================
print("\n" + "="*100)
print("【6】课程分布统计 - 尝试识别班级每天每科出现次数")
print("="*100)

for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
    print(f"\n--- Sheet: '{sheet_name}' ---")
    
    # 读取所有数据到二维列表
    all_data = []
    for r in range(1, ws.max_row+1):
        row_data = []
        for c in range(1, ws.max_column+1):
            val = ws.cell(row=r, column=c).value
            row_data.append(val if val is not None else "")
        all_data.append(row_data)
    
    # 打印前3行完整内容用于判断结构
    print("  前3行完整内容:")
    for i in range(min(3, len(all_data))):
        print(f"    行{i+1}: {all_data[i][:15]}")

# ============================================================
# 7. 教师课分布
# ============================================================
print("\n" + "="*100)
print("【7】教师课分布统计")
print("="*100)

for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
    print(f"\n--- Sheet: '{sheet_name}' ---")
    
    # 收集所有含中文的单元格，尝试识别教师名
    teacher_cells = defaultdict(list)
    for r in range(1, ws.max_row+1):
        for c in range(1, ws.max_column+1):
            val = ws.cell(row=r, column=c).value
            if val is not None and isinstance(val, str):
                # 课程表单元格通常格式为 "科目+教师名" 或 "科目\n教师名"
                # 教师名通常是2-3个中文字
                lines = val.replace('\r', '\n').split('\n')
                for line in lines:
                    line = line.strip()
                    if line:
                        teacher_cells[line].append((r, c))
    
    # 统计出现次数最多的文本（可能是教师名或课程名）
    text_counter = Counter()
    for text, cells in teacher_cells.items():
        text_counter[text] = len(cells)
    
    print("  出现频率最高的文本(前20):")
    for text, count in text_counter.most_common(20):
        print(f"    '{text}': {count}次")

print("\n" + "="*100)
print("分析完成！")
print("="*100)
