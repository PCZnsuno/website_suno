import pandas as pd
from collections import defaultdict

ref_path = r'C:\Users\sl315\Desktop\2526第一学期高二级课程表.xlsx'
df = pd.read_excel(ref_path, sheet_name='Sheet1', header=None)

day_class1_col = {
    '星期一': 3, '星期二': 24, '星期三': 45, '星期四': 69, '星期五': 90,
}
period_data_rows = [4, 5, 6, 7, 10, 11, 12]
period_nums = [1, 2, 3, 4, 5, 6, 7]

print("=" * 80)
print("参考课程表中所有配对课/特殊课单元格")
print("=" * 80)

paired_cells = []
for day, cls1_col in day_class1_col.items():
    for ri, data_row in enumerate(period_data_rows):
        period = period_nums[ri]
        for cls_num in range(1, 21):
            col = cls1_col + cls_num - 1
            if col < len(df.columns) and data_row < len(df):
                cell = df.iloc[data_row, col]
                if pd.notna(cell):
                    cell_str = str(cell).strip()
                    if cell_str in ['单体双通', '双体单通', '单体双', '双体单']:
                        paired_cells.append((day, period, cls_num, cell_str))

print(f"\n配对课单元格总数: {len(paired_cells)}")
for day, period, cls, val in paired_cells:
    print(f"  {day} 第{period}节 班级{cls}: {val}")

# Also check the note section for explanations
print("\n" + "=" * 80)
print("备注说明（行12）")
print("=" * 80)
row12 = df.iloc[12]
for c in range(min(111, len(row12))):
    val = str(row12[c]).strip() if pd.notna(row12[c]) else ''
    if val and len(val) > 5:
        print(f"  col {c}: {val}")
        break

# Check rows 22-24 for the pairing labels
print("\n" + "=" * 80)
print("配对标签区域（行22-24）")
print("=" * 80)
for r in range(22, min(25, len(df))):
    row = df.iloc[r]
    for c in range(min(111, len(row))):
        val = str(row[c]).strip() if pd.notna(row[c]) else ''
        if val and val not in ['NaN', 'nan', '选择性', '合格性'] and not val.isdigit():
            print(f"  行{r} col{c}: {val}")

# Also look at the paired cells more carefully
# "单体双通" = 单周体育，双周通用技术
# "双体单通" = 双周体育，单周通用技术

# Let me check what teachers are assigned to these cells
print("\n" + "=" * 80)
print("配对课的教师分配")
print("=" * 80)
for day, period, cls, val in paired_cells[:10]:
    print(f"  {day} 第{period}节 班级{cls}: {val}")
    # The cell value itself is the label, not teacher name
    # This is different from regular cells which show "科目+教师"
