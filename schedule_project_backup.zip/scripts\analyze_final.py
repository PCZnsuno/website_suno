import pandas as pd
import re
from collections import defaultdict, Counter

ref_path = r'C:\Users\sl315\Desktop\2526第一学期高二级课程表.xlsx'
teacher_path = r'C:\Users\sl315\Desktop\2025-2026学年度第一学期高二级教师工作安排.xlsx'

df = pd.read_excel(ref_path, sheet_name='Sheet1', header=None)
print(f"Shape: {df.shape}")

# Print key rows to verify structure
print("\n=== Row 3 (class numbers) ===")
row3 = df.iloc[3]
for c in range(min(111, len(row3))):
    val = str(row3[c]).strip() if pd.notna(row3[c]) else ''
    if val: print(f"  col {c}: {val}")

print("\n=== Row 4 (period 1 data) ===")
row4 = df.iloc[4]
for c in range(min(111, len(row4))):
    val = str(row4[c]).strip() if pd.notna(row4[c]) else ''
    if val: print(f"  col {c}: {val}")

print("\n=== Row 9 (afternoon header) ===")
row9 = df.iloc[9]
for c in range(60, min(111, len(row9))):
    val = str(row9[c]).strip() if pd.notna(row9[c]) else ''
    if val: print(f"  col {c}: {val}")

# Correct column mapping based on actual data:
# Left half: Mon(start col 2), Tue(start col 24), Wed(start col 45)
# Right half: Thu(start col 68), Fri(start col 90)
# Each day: [节/empty] [1] [2] ... [20] [走班] = 22 cols
# Class 1 offset from day start: +1

# Data rows: 4=period1, 5=period2, 6=period3, 7=period4, 10=period5, 11=period6, 12=period7

day_class1_col = {
    '星期一': 3,   # col 2=节, col 3=class 1
    '星期二': 24,  # col 24=class 1 directly (no 节 label)
    '星期三': 45,  # col 45=class 1
    '星期四': 69,  # col 68=节, col 69=class 1
    '星期五': 90,  # col 90=class 1
}

period_data_rows = [4, 5, 6, 7, 10, 11, 12]  # rows for periods 1-7
period_nums = [1, 2, 3, 4, 5, 6, 7]

# Parse
teacher_schedule = defaultdict(list)
teacher_daily = defaultdict(lambda: defaultdict(int))

for day, cls1_col in day_class1_col.items():
    for ri, data_row in enumerate(period_data_rows):
        period = period_nums[ri]
        for cls_num in range(1, 21):
            col = cls1_col + cls_num - 1  # class 1 at cls1_col, class 2 at cls1_col+1
            if col < len(df.columns) and data_row < len(df):
                cell = df.iloc[data_row, col]
                if pd.notna(cell):
                    cell_str = str(cell).strip()
                    if cell_str and cell_str not in ['NaN', 'nan', '班会', '单体双通', '双体单通', '']:
                        teacher_schedule[cell_str].append((day, period, cls_num))
                        teacher_daily[cell_str][day] += 1

total_entries = sum(len(v) for v in teacher_schedule.values())
print(f"\n解析到 {len(teacher_schedule)} 位教师")
print(f"总排课条目: {total_entries}")

# Also parse walk class column (col = cls1_col + 20)
for day, cls1_col in day_class1_col.items():
    walk_col = cls1_col + 20  # 走班 column
    for ri, data_row in enumerate(period_data_rows):
        period = period_nums[ri]
        if walk_col < len(df.columns) and data_row < len(df):
            cell = df.iloc[data_row, walk_col]
            if pd.notna(cell):
                cell_str = str(cell).strip()
                if cell_str and cell_str not in ['NaN', 'nan', '']:
                    teacher_schedule[cell_str].append((day, period, '走班'))
                    teacher_daily[cell_str][day] += 1

total_entries2 = sum(len(v) for v in teacher_schedule.values())
print(f"含走班后排课条目: {total_entries2}")

# Teacher workload
teacher_total = {t: len(slots) for t, slots in teacher_schedule.items()}
sorted_teachers = sorted(teacher_total.items(), key=lambda x: -x[1])

print(f"\n{'教师':<12} {'总课时':>6} {'周一':>4} {'周二':>4} {'周三':>4} {'周四':>4} {'周五':>4} {'最大日':>6} {'天数':>4}")
print("-" * 60)
for teacher, total in sorted_teachers[:50]:
    d = teacher_daily[teacher]
    days_active = sum(1 for day in ['星期一','星期二','星期三','星期四','星期五'] if d.get(day,0) > 0)
    max_day = max(d.values()) if d else 0
    print(f"{teacher:<12} {total:>6} {d.get('星期一',0):>4} {d.get('星期二',0):>4} {d.get('星期三',0):>4} {d.get('星期四',0):>4} {d.get('星期五',0):>4} {max_day:>6} {days_active:>4}")

# Statistics
max_per_teacher = {t: max(teacher_daily[t].values()) for t in teacher_daily}
max_dist = Counter(max_per_teacher.values())
print("\n每位教师最大日课时分布:")
for v in sorted(max_dist.keys()):
    print(f"  {v}节/天: {max_dist[v]}位教师")

days_per_teacher = {t: len(set(d for d,p,c in teacher_schedule[t])) for t in teacher_schedule}
days_dist = Counter(days_per_teacher.values())
print("\n每位教师每周上课天数:")
for v in sorted(days_dist.keys()):
    print(f"  {v}天: {days_dist[v]}位教师")

daily_totals = defaultdict(int)
for t in teacher_daily:
    for day, cnt in teacher_daily[t].items():
        daily_totals[day] += cnt
print("\n每天总排课量:")
for day in ['星期一','星期二','星期三','星期四','星期五']:
    print(f"  {day}: {daily_totals.get(day,0)}节")

# Parse teacher work arrangement
print("\n" + "=" * 80)
print("教师工作安排表")
print("=" * 80)

df2 = pd.read_excel(teacher_path, sheet_name='Sheet1', header=None)
teachers_info = []
for r in range(3, len(df2)):
    row = df2.iloc[r]
    for block_start in [0, 7]:
        name_col = block_start + 2
        abbr_col = block_start + 3
        classes_col = block_start + 4
        hours_col = block_start + 5
        name = str(row[name_col]).strip() if pd.notna(row[name_col]) else ''
        abbr = str(row[abbr_col]).strip() if pd.notna(row[abbr_col]) else ''
        classes = str(row[classes_col]).strip() if pd.notna(row[classes_col]) else ''
        hours_raw = row[hours_col]
        try:
            hours = int(hours_raw) if pd.notna(hours_raw) else 0
        except:
            hours = 0
        if name and name != 'nan' and hours > 0:
            teachers_info.append({'name': name, 'abbr': abbr, 'classes': classes, 'hours': hours})

teachers_info = [t for t in teachers_info if '产假' not in t['classes'] and '退休' not in t['classes']]
for t in teachers_info:
    t['class_count'] = len(re.findall(r'\d+', t['classes']))

print(f"有效教师: {len(teachers_info)}人")
print(f"总课时: {sum(t['hours'] for t in teachers_info)}节")

hour_dist = Counter(t['hours'] for t in teachers_info)
print("\n每周课时分布:")
for v in sorted(hour_dist.keys()):
    print(f"  {v}节/周: {hour_dist[v]}位教师")

class_dist = Counter(t['class_count'] for t in teachers_info)
print("\n任教班级数分布:")
for v in sorted(class_dist.keys()):
    print(f"  {v}个班: {class_dist[v]}位教师")

# Summary
print("\n" + "=" * 80)
print("核心对比分析")
print("=" * 80)
print(f"""
参考课程表:
  排课总量: {total_entries2}节
  教师数: {len(teacher_schedule)}人
  每天排课: {sum(daily_totals.values())}节 (7节/天 × 20班 = 应有 {7*5*20}节，含班会和走班)
  教师最大日课时: {max(max_per_teacher.values())}节
  平均最大日课时: {sum(max_per_teacher.values())/len(max_per_teacher):.1f}节
  上课天数: 平均 {sum(days_per_teacher.values())/len(days_per_teacher):.1f}天

教师工作安排:
  有效教师: {len(teachers_info)}人
  总课时: {sum(t['hours'] for t in teachers_info)}节
  平均课时: {sum(t['hours'] for t in teachers_info)/len(teachers_info):.1f}节/周
  平均任教班级: {sum(t['class_count'] for t in teachers_info)/len(teachers_info):.1f}个
""")
