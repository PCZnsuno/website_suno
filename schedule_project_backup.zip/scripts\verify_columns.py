# -*- coding: utf-8 -*-
import openpyxl

filepath = r"C:\Users\sl315\.trae-cn\attachments\6a54eed2739a715a6232c351\c8327b87-f461-4348-9873-d307a3cdecac_95b77871-fbe8-4cfa-87bd-c9865cc218fe_2526第一学期高二级课程表.xlsx"

wb = openpyxl.load_workbook(filepath, data_only=True)
ws = wb['Sheet1']

# Check row 4 headers to verify column mapping
print("Row 4 (header row) for all non-empty columns:")
for col in range(1, 115):
    val = ws.cell(row=4, column=col).value
    if val is not None:
        col_letter = openpyxl.utils.get_column_letter(col)
        print(f"  Col {col_letter}({col}): {val}")

print("\nRow 10 (afternoon header):")
for col in range(1, 115):
    val = ws.cell(row=10, column=col).value
    if val is not None:
        col_letter = openpyxl.utils.get_column_letter(col)
        print(f"  Col {col_letter}({col}): {val}")

# Verify specific cells
print("\nRow 5 (period 1), checking Friday columns:")
for col in range(89, 115):
    val = ws.cell(row=5, column=col).value
    if val is not None:
        col_letter = openpyxl.utils.get_column_letter(col)
        print(f"  Col {col_letter}({col}): {val}")
