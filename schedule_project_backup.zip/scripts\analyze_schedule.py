import pandas as pd
import json
import sys

# File paths
ref_path = r'C:\Users\sl315\Desktop\2526第一学期高二级课程表.xlsx'
teacher_path = r'C:\Users\sl315\Desktop\2025-2026学年度第一学期高二级教师工作安排.xlsx'
download_ref = r'C:\Users\sl315\Downloads\46b70dc4-bba4-4362-836b-c03c18cb950d.xls'

print("=" * 60)
print("1. 参考课程表 - 工作表列表")
print("=" * 60)
try:
    xl = pd.ExcelFile(ref_path)
    print(f"Sheets: {xl.sheet_names}")
except Exception as e:
    print(f"读取失败: {e}")
    sys.exit(1)

# Read all sheets
for sn in xl.sheet_names:
    df = pd.read_excel(ref_path, sheet_name=sn, header=None)
    print(f"\n--- Sheet: {sn} (rows={df.shape[0]}, cols={df.shape[1]}) ---")
    print("前25行:")
    print(df.head(25).to_string())

print("\n" + "=" * 60)
print("2. 教师工作安排 - 工作表列表")
print("=" * 60)
try:
    xl2 = pd.ExcelFile(teacher_path)
    print(f"Sheets: {xl2.sheet_names}")
    for sn in xl2.sheet_names:
        df2 = pd.read_excel(teacher_path, sheet_name=sn, header=None)
        print(f"\n--- Sheet: {sn} (rows={df2.shape[0]}, cols={df2.shape[1]}) ---")
        print("前20行:")
        print(df2.head(20).to_string())
except Exception as e:
    print(f"读取失败: {e}")

print("\n" + "=" * 60)
print("3. 下载的参考课程表")
print("=" * 60)
try:
    xl3 = pd.ExcelFile(download_ref)
    print(f"Sheets: {xl3.sheet_names}")
    for sn in xl3.sheet_names:
        df3 = pd.read_excel(download_ref, sheet_name=sn, header=None)
        print(f"\n--- Sheet: {sn} (rows={df3.shape[0]}, cols={df3.shape[1]}) ---")
        print("前25行:")
        print(df3.head(25).to_string())
except Exception as e:
    print(f"读取失败: {e}")
