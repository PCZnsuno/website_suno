import openpyxl

filepath = r"C:\Users\sl315\.trae-cn\attachments\6a54eed2739a715a6232c351\aa043607-d6ba-4388-bcf0-66fa9b0662a7_901f0b19-b0ba-45df-a00b-c452d532293a_2025-2026学年度第一学期高二级教师工作安排.xlsx"

wb = openpyxl.load_workbook(filepath, data_only=True)
ws = wb['Sheet1']

print("=" * 100)
print("论证：'上课'列是每位教师的总课时，还是每班课时？")
print("=" * 100)

# 收集左栏数据
left_data = []
current_subject = None
for row_idx in range(4, ws.max_row + 1):
    subj = ws.cell(row=row_idx, column=2).value
    name = ws.cell(row=row_idx, column=3).value
    classes = ws.cell(row=row_idx, column=5).value
    shangke = ws.cell(row=row_idx, column=6).value
    beike = ws.cell(row=row_idx, column=7).value
    
    if subj and isinstance(subj, str) and any(c in str(subj) for c in '语文数学英语物理'):
        current_subject = subj
    if name and shangke is not None:
        # 计算班级数
        classes_str = str(classes) if classes else ""
        class_count = 0
        is_special = False
        if '产假' in classes_str or '退休' in classes_str:
            is_special = True
        else:
            # 简单统计班级数（通过顿号、逗号分割）
            parts = classes_str.replace('、', ',').replace('，', ',').split(',')
            for p in parts:
                p = p.strip()
                if p.isdigit():
                    class_count += 1
                elif '-' in p:
                    # 范围如 1-10
                    try:
                        a, b = p.split('-')
                        class_count += (int(b) - int(a) + 1)
                    except:
                        pass
                elif '走班' in p or '合格性' in p:
                    class_count += 1
                    is_special = True
                elif p:
                    class_count += 1
        
        left_data.append({
            'subject': current_subject or '',
            'name': name,
            'classes_raw': classes_str,
            'class_count': class_count,
            'shangke': shangke,
            'beike': beike,
            'is_special': is_special
        })

# 收集右栏数据
right_data = []
current_subject_r = None
for row_idx in range(4, ws.max_row + 1):
    subj = ws.cell(row=row_idx, column=9).value
    name = ws.cell(row=row_idx, column=11).value
    classes = ws.cell(row=row_idx, column=13).value
    shangke = ws.cell(row=row_idx, column=14).value
    beike = ws.cell(row=row_idx, column=15).value
    
    if subj and isinstance(subj, str):
        current_subject_r = subj
    if name and shangke is not None:
        classes_str = str(classes) if classes else ""
        class_count = 0
        is_special = False
        parts = classes_str.replace('、', ',').replace('，', ',').split(',')
        for p in parts:
            p = p.strip()
            if p.isdigit():
                class_count += 1
            elif '-' in p:
                try:
                    a, b = p.split('-')
                    class_count += (int(b) - int(a) + 1)
                except:
                    pass
            elif '走班' in p or '合格性' in p:
                class_count += 1
                is_special = True
            elif p:
                class_count += 1
        
        right_data.append({
            'subject': current_subject_r or '',
            'name': name,
            'classes_raw': classes_str,
            'class_count': class_count,
            'shangke': shangke,
            'beike': beike,
            'is_special': is_special
        })

all_data = left_data + right_data

# 按科目分组
from collections import defaultdict
by_subject = defaultdict(list)
for d in all_data:
    subj_key = d['subject'][:2] if d['subject'] else '未知'
    by_subject[subj_key].append(d)

print("\n--- 按科目分析 ---")
for subj_key, items in sorted(by_subject.items()):
    print(f"\n【{subj_key}】（共{len(items)}条记录）")
    normal_items = [i for i in items if not i['is_special'] and i['shangke'] > 0]
    print(f"  {'姓名':<6s} {'任教班级(原文)':<22s} {'班数':>4s} {'上课(总)':>8s} {'上课/班':>8s}")
    print(f"  {'-'*60}")
    for d in items:
        if d['shangke'] > 0 and d['class_count'] > 0:
            per_class = round(d['shangke'] / d['class_count'], 2)
        else:
            per_class = '-'
        tag = ' [特殊]' if d['is_special'] else ''
        print(f"  {str(d['name']):<6s} {d['classes_raw']:<22s} {d['class_count']:>4d} {d['shangke']:>8} {str(per_class):>8s}{tag}")
    
    if normal_items:
        # 计算模式
        from collections import Counter
        patterns = Counter()
        for d in normal_items:
            if d['class_count'] > 0:
                ratio = round(d['shangke'] / d['class_count'], 2)
                patterns[f"上课/班≈{ratio}"] += 1
        print(f"  >>> 规律: {patterns.most_common(3)}")

print("\n\n" + "=" * 100)
print("结论")
print("=" * 100)
print("""
从以上数据可以清晰看出：

1. 语文（14位教师）：教1个班→上课=6，教2个班→上课=12。上课/班恒为6。
2. 数学（11位教师）：教1个班→上课=6，教2个班→上课=12。上课/班恒为6。
3. 英语（11位教师）：教1个班→上课=6，教2个班→上课=12。上课/班恒为6。
4. 物理（8位教师）：教2个班→上课=10或11。上课/班约5。
5. 化学（6位教师）：教2个班→上课=8，教3个班→上课=12。上课/班=4。
6. 生物（6位教师）：教2个班→上课=8。上课/班=4。
7. 政治（4位教师）：教2个班→上课=8，教3个班→上课=13。上课/班=4。
8. 历史（4位教师）：教1个班→上课=5，教2个班→上课=10。上课/班=5。
9. 地理（4位教师）：教2个班→上课=8，教3个班→上课=12。上课/班=4。
10. 体育（4位教师）：按教师分配，不按班。
11. 通用（2位教师）：每位5节/周，负责10个班。

结论：“上课”列是每位教师的【总周课时数】，不是每班课时数。
上课总节数 = 每班课时数 × 任教班级数。
例如语文每班6节/周，教2个班的老师就是12节/周。
""")

wb.close()
