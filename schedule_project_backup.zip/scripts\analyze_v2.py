import pandas as pd
import re
from collections import defaultdict, Counter

ref_path = r'C:\Users\sl315\Desktop\2526第一学期高二级课程表.xlsx'
teacher_path = r'C:\Users\sl315\Desktop\2025-2026学年度第一学期高二级教师工作安排.xlsx'

df = pd.read_excel(ref_path, sheet_name='Sheet1', header=None)

# Column mapping from previous analysis:
# Mon class1=col3, Tue class1=col24, Wed class1=col45, Thu class1=col69, Fri class1=col90
# Data rows: 4=period1, 5=period2, 6=period3, 7=period4, 10=period5, 11=period6, 12=period7

day_class1_col = {
    '星期一': 3, '星期二': 24, '星期三': 45, '星期四': 69, '星期五': 90,
}
period_data_rows = [4, 5, 6, 7, 10, 11, 12]
period_nums = [1, 2, 3, 4, 5, 6, 7]

# Count ALL courses including paired cells
regular_count = 0
paired_count = 0
special_count = 0  # 单体双通, 双体单通, 班会

for day, cls1_col in day_class1_col.items():
    for ri, data_row in enumerate(period_data_rows):
        period = period_nums[ri]
        for cls_num in range(1, 21):
            col = cls1_col + cls_num - 1
            if col < len(df.columns) and data_row < len(df):
                cell = df.iloc[data_row, col]
                if pd.notna(cell):
                    cell_str = str(cell).strip()
                    if cell_str in ['单体双通', '双体单通']:
                        paired_count += 2  # Two courses in one cell
                    elif cell_str == '班会':
                        special_count += 1
                    elif cell_str and cell_str not in ['NaN', 'nan', '']:
                        regular_count += 1

total = regular_count + paired_count
print(f"参考课程表统计:")
print(f"  常规课程（单节课）: {regular_count}节")
print(f"  配对课程（单双周）: {paired_count}节 ({paired_count//2}个配对单元格)")
print(f"  班会: {special_count}节")
print(f"  实际总课时（不含班会）: {total}节")
print(f"  每班每天平均: {total / 20 / 5:.1f}节")

# Now compare with teacher arrangement total
df2 = pd.read_excel(teacher_path, sheet_name='Sheet1', header=None)
total_arr = 0
for r in range(3, len(df2)):
    row = df2.iloc[r]
    for block_start in [0, 7]:
        hours_col = block_start + 5
        hours_raw = row[hours_col]
        try:
            hours = int(hours_raw) if pd.notna(hours_raw) else 0
        except:
            hours = 0
        name_col = block_start + 2
        classes_col = block_start + 4
        name = str(row[name_col]).strip() if pd.notna(row[name_col]) else ''
        classes = str(row[classes_col]).strip() if pd.notna(row[classes_col]) else ''
        if name and name != 'nan' and '产假' not in classes and '退休' not in classes:
            total_arr += hours

print(f"\n教师工作安排总课时: {total_arr}节")
print(f"参考课程表排课量: {total}节")
print(f"差异: {total_arr - total}节（可能是走班/班会等特殊安排）")

# === Now analyze what's in our system ===
print("\n" + "=" * 80)
print("参考课程表 - 完整教师每日分布（含配对课）")
print("=" * 80)

teacher_schedule = defaultdict(list)
teacher_daily = defaultdict(lambda: defaultdict(int))

for day, cls1_col in day_class1_col.items():
    for ri, data_row in enumerate(period_data_rows):
        period = period_nums[ri]
        for cls_num in range(1, 21):
            col = cls1_col + cls_num - 1
            if col < len(df.columns) and data_row < len(df):
                cell = df.iloc[data_row, col]
                if pd.notna(cell):
                    cell_str = str(cell).strip()
                    if cell_str and cell_str not in ['NaN', 'nan', '班会', '']:
                        # For paired cells like "单体双通", count as 1 entry per teacher
                        teacher_schedule[cell_str].append((day, period, cls_num))
                        teacher_daily[cell_str][day] += 1
        # Walk class
        walk_col = cls1_col + 20
        if walk_col < len(df.columns) and data_row < len(df):
            cell = df.iloc[data_row, walk_col]
            if pd.notna(cell):
                cell_str = str(cell).strip()
                if cell_str and cell_str not in ['NaN', 'nan', '']:
                    teacher_schedule[cell_str].append((day, period, '走班'))
                    teacher_daily[cell_str][day] += 1

# Key analysis: what's the maximum daily load?
max_per_teacher = {t: max(teacher_daily[t].values()) for t in teacher_daily}
max_dist = Counter(max_per_teacher.values())
print("\n教师最大日课时分布（含走班/配对）:")
for v in sorted(max_dist.keys()):
    print(f"  {v}节/天: {max_dist[v]}位教师")

# Find teachers with highest daily loads
print("\n日课时>=4的教师:")
for t in sorted(max_per_teacher, key=lambda x: -max_per_teacher[x]):
    if max_per_teacher[t] >= 4:
        d = teacher_daily[t]
        print(f"  {t}: 最大{max_per_teacher[t]}节/天 | 周一{d.get('星期一',0)} 周二{d.get('星期二',0)} 周三{d.get('星期三',0)} 周四{d.get('星期四',0)} 周五{d.get('星期五',0)}")

# Subject per class per day in reference
print("\n" + "=" * 80)
print("参考课程表 - 每班每天科目数检查")
print("=" * 80)

# Parse by class
class_schedule = defaultdict(lambda: defaultdict(list))  # class -> day -> [subjects]
for day, cls1_col in day_class1_col.items():
    for ri, data_row in enumerate(period_data_rows):
        period = period_nums[ri]
        for cls_num in range(1, 21):
            col = cls1_col + cls_num - 1
            if col < len(df.columns) and data_row < len(df):
                cell = df.iloc[data_row, col]
                if pd.notna(cell):
                    cell_str = str(cell).strip()
                    if cell_str and cell_str not in ['NaN', 'nan', '班会', '']:
                        # Extract subject (remove teacher name - last 1-2 chars)
                        # Format: 化学锋, 生物灿, etc.
                        # Subject is everything except the last character(s)
                        subj = cell_str
                        class_schedule[cls_num][day].append(subj)

max_per_class_day = 0
for cls in class_schedule:
    for day in class_schedule[cls]:
        cnt = len(class_schedule[cls][day])
        if cnt > max_per_class_day:
            max_per_class_day = cnt
        if cnt >= 6:
            print(f"  {cls}班 {day}: {cnt}节课")

print(f"每班每天最大节数: {max_per_class_day}")

# Check how many slots are empty per class per day
empty_per_class_day = {}
for cls in range(1, 21):
    for day in ['星期一','星期二','星期三','星期四','星期五']:
        used = len(class_schedule[cls][day])
        total_slots = 7  # 7 periods per day
        empty = total_slots - used
        if empty < 0:
            print(f"  WARNING: {cls}班 {day}: {used}节课但只有{total_slots}个时段！")
