import openpyxl
import sys

filepath = r"C:\Users\sl315\.trae-cn\attachments\6a54eed2739a715a6232c351\c8327b87-f461-4348-9873-d307a3cdecac_95b77871-fbe8-4cfa-87bd-c9865cc218fe_2526第一学期高二级课程表.xlsx"

wb = openpyxl.load_workbook(filepath, data_only=True)
print(f"Sheet names: {wb.sheetnames}")

for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
    print(f"\n{'='*80}")
    print(f"Sheet: {sheet_name}")
    print(f"Dimensions: {ws.dimensions}")
    print(f"Max row: {ws.max_row}, Max col: {ws.max_column}")
    
    # Check for merged cells
    print(f"Merged cells: {list(ws.merged_cells.ranges)}")
    
    # Print all data
    print(f"\nAll data (rows 1-{ws.max_row}, cols 1-{ws.max_column}):")
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, max_col=ws.max_column, values_only=False):
        row_data = []
        for cell in row:
            val = cell.value
            if val is not None:
                row_data.append(f"[{cell.coordinate}]={repr(val)}")
        if row_data:
            print(f"  Row {row[0].row}: {', '.join(row_data)}")
        else:
            print(f"  Row {row[0].row}: (empty)")
