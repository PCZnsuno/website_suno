import pandas as pd
import re
from collections import defaultdict, Counter

ref_path = r'C:\Users\sl315\Desktop\2526第一学期高二级课程表.xlsx'
teacher_path = r'C:\Users\sl315\Desktop\2025-2026学年度第一学期高二级教师工作安排.xlsx'

# ===== 1. Parse reference schedule =====
print("=" * 80)
print("1. 解析参考课程表")
print("=" * 80)

df = pd.read_excel(ref_path, sheet_name='Sheet1', header=None)

# The schedule is organized as a class-centric grid
# Columns: 节 | 1 | 2 | 3 | ... | 20 | 走班 (repeated for each day)
# Rows: 上午 header | 1 | 2 | 3 | 4 | separator | 下午 header | 5 | 6 | 7

# Find '节' columns to identify day boundaries
jie_cols = []
for c in range(len(df.columns)):
    for r in range(len(df)):
        val = str(df.iloc[r, c]).strip() if pd.notna(df.iloc[r, c]) else ''
        if val == '节':
            jie_cols.append((r, c))
            break

print(f"Found '节' at: {jie_cols}")

# Day mapping based on jie_cols positions
# Left block: 星期一, 星期二, 星期三
# Right block: 星期四, 星期五
# Each day block: 节 + 20 classes + 走班 = 22 columns

# Let me find the actual column ranges for each day
# Row 2 has day headers
row2 = df.iloc[2]
day_positions = {}
for c in range(len(row2)):
    val = str(row2[c]).strip() if pd.notna(row2[c]) else ''
    if val in ['星期一','星期二','星期三','星期四','星期五']:
        day_positions[val] = c

print(f"Day positions from row 2: {day_positions}")

# Parse the schedule
# Period rows (after removing headers/separators)
# Row 4: 上午 header (skip)
# Rows 5-8: periods 1-4
# Row 9: separator (skip)
# Row 10: 下午 header (skip) 
# Rows 11-13: periods 5-7

# For each day, the class columns start at the '节' column + 1
# Let's find all '节' in the period data rows
period_data_rows = [5, 6, 7, 8, 11, 12, 13]  # periods 1-7
period_labels = [1, 2, 3, 4, 5, 6, 7]

# Build teacher schedule
teacher_schedule = defaultdict(list)

# For each day, find its column range
day_col_ranges = {}
sorted_days = ['星期一', '星期二', '星期三', '星期四', '星期五']

# The jie_cols tell us where each day starts
# Let me find jie_cols in the period data rows
jie_in_data = []
for c in range(len(df.columns)):
    for r in period_data_rows:
        val = str(df.iloc[r, c]).strip() if pd.notna(df.iloc[r, c]) else ''
        if val in ['1', '2', '3', '4', '5', '6', '7']:
            # This is a period number column
            pass

# Alternative approach: scan row 3 for class numbers
row3 = df.iloc[3]
class_num_cols = {}
for c in range(len(row3)):
    val = str(row3[c]).strip() if pd.notna(row3[c]) else ''
    if val.isdigit() and 1 <= int(val) <= 20:
        # Check if this is under a day header
        class_num_cols[c] = int(val)

print(f"Class number columns: {dict(sorted(class_num_cols.items()))}")

# Group class columns by day
# Each day has 22 columns: 节 + 1..20 + 走班
# Find the '节' markers in row 3
jie_markers = []
for c in range(len(row3)):
    val = str(row3[c]).strip() if pd.notna(row3[c]) else ''
    if val == '节':
        jie_markers.append(c)

print(f"'节' markers in row 3: {jie_markers}")

# Map days to jie markers
# The schedule has two halves: left (3 days) and right (2 days)
# Left: 星期一, 星期二, 星期三 at jie_markers[0], jie_markers[1], jie_markers[2]
# Right: 星期四, 星期五 - need to find in the right half

# Also check row 9 for the afternoon section
row9 = df.iloc[9]
jie_markers_afternoon = []
for c in range(len(row9)):
    val = str(row9[c]).strip() if pd.notna(row9[c]) else ''
    if val == '节':
        jie_markers_afternoon.append(c)

print(f"'节' markers in row 9 (afternoon): {jie_markers_afternoon}")

# Combine: morning jie markers + afternoon jie markers
# Each day has a morning and afternoon '节' marker
# Total should be 10 (5 days × 2 sections)

# For simplicity, let me use the morning markers to define day boundaries
# and assume each day block is 22 columns wide

all_jie = sorted(set(jie_markers + jie_markers_afternoon))
print(f"All '节' markers: {all_jie}")

# Now parse the actual schedule
# For each day, class 1 starts at jie_col + 1, class 2 at jie_col + 2, etc.
# 走班 at jie_col + 21

# Let me map each jie marker to a day
# Based on the data structure:
# Left half: 星期一(上午), 星期二(上午), 星期三(上午), 星期一(下午), 星期二(下午), 星期三(下午)
# Right half: 星期四(上午), 星期五(上午), 星期四(下午), 星期五(下午)

# Actually, let me just use the day_positions from row 2
# 星期一 starts at col 2, each day is ~22 cols wide
# But looking at the data, the actual layout is:

# Row 2 shows: 星期一 at some col, 星期二 at another, etc.
# Let me use these to determine the column ranges

for day, start_col in day_positions.items():
    print(f"{day}: starts at col {start_col}")

# Each day block is 22 columns wide (节 + 20 classes + 走班)
# But the '走班' column might be shared or handled differently

# Let me just scan all cells and extract teacher-class-period-day mappings
print("\n" + "=" * 80)
print("2. 提取所有排课数据")
print("=" * 80)

# For each day, I know the starting column
# Class 1 is at start_col + 1, class 2 at start_col + 2, etc.
# But I need to verify this

# Let me check what's in the cells for 星期一
mon_start = day_positions.get('星期一', 2)
print(f"\n星期一 列范围: {mon_start} to {mon_start+22}")
print("Row 5 (period 1):")
for c in range(mon_start, min(mon_start+23, len(df.columns))):
    val = df.iloc[5, c] if pd.notna(df.iloc[5, c]) else ''
    print(f"  col {c}: {val}")

print("\nRow 6 (period 2):")
for c in range(mon_start, min(mon_start+23, len(df.columns))):
    val = df.iloc[6, c] if pd.notna(df.iloc[6, c]) else ''
    print(f"  col {c}: {val}")
