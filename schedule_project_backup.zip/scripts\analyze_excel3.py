# -*- coding: utf-8 -*-
import openpyxl
from collections import defaultdict, Counter
import re

FILE_PATH = r"c:\Users\sl315\.trae-cn\attachments\6a54eed2739a715a6232c351\c8327b87-f461-4348-9873-d307a3cdecac_95b77871-fbe8-4cfa-87bd-c9865cc218fe_2526第一学期高二级课程表.xlsx"

def col_letter(n):
    result = ""
    while n > 0:
        n, remainder = divmod(n - 1, 26)
        result = chr(65 + remainder) + result
    return result

wb = openpyxl.load_workbook(FILE_PATH, data_only=True)
ws = wb['Sheet1']

# 天的列范围定义
day_configs = [
    ("星期一", 3, 24),   # C to X
    ("星期二", 25, 45),  # Y to AS
    ("星期三", 46, 66),  # AT to BN
    ("星期四", 69, 90),  # BQ to CL
    ("星期五", 91, 111), # CM to DG
]

# 上午行和下午行
morning_rows = [5, 6, 7, 8]  # 第1-4节
afternoon_rows = [11, 12, 13]  # 第5-7节(第7节=班会)
all_class_rows = morning_rows + afternoon_rows

# ============================================================
# 6. 每个班每天同一科目最多几节
# ============================================================
print("=" * 120)
print("【6】每个班每天每科出现次数统计")
print("=" * 120)

def extract_subject(cell_val):
    """从 '化学锋' 格式中提取科目名（去掉最后1-2个教师名字符）"""
    if not cell_val or cell_val in ['单体双通', '双体单通', '班  会', '']:
        return cell_val
    s = str(cell_val).strip()
    # 常见科目
    known_subjects = [
        '语文', '数学', '英语', '物理', '化学', '生物',
        '政治', '历史', '地理', '体育', '通用', '班会',
        '单体双通', '双体单通', '美术', '音乐', '信息'
    ]
    for subj in known_subjects:
        if s.startswith(subj):
            return subj
    return s  # 无法识别则返回原值

for day_name, start_col, end_col in day_configs:
    print(f"\n--- {day_name} ---")
    
    # 获取班级列（跳过"节"列和"走班"列）
    class_cols = []
    for c in range(start_col, end_col + 1):
        h4 = ws.cell(row=4, column=c).value
        if h4 is not None:
            h4_str = str(h4).strip()
            if h4_str.isdigit():
                class_cols.append((c, int(h4_str)))
    
    max_subjects = {}  # 班级 -> {科目: 最大每日出现次数}
    
    for col_idx, class_num in class_cols:
        daily_subjects = []
        for row_num in all_class_rows:
            val = ws.cell(row=row_num, column=col_idx).value
            if val:
                subj = extract_subject(str(val))
                daily_subjects.append(subj)
        
        # 统计
        subj_counter = Counter(daily_subjects)
        max_subjects[class_num] = subj_counter
        
        # 找出出现>1次的科目
        doubled = {s: c for s, c in subj_counter.items() if c > 1 and s not in ['单体双通', '双体单通']}
        if doubled:
            print(f"  班级{class_num:2d}(列{col_idx:3d}): 有科目同天多节 -> {doubled}  全部: {dict(subj_counter)}")
    
    # 汇总：该天所有班级中，各科最多出现次数
    all_max = defaultdict(int)
    for class_num, counter in max_subjects.items():
        for subj, cnt in counter.items():
            if subj not in ['单体双通', '双体单通']:
                all_max[subj] = max(all_max[subj], cnt)
    print(f"  {day_name}汇总 - 各科在任一班级中单日最大出现次数:")
    for subj, cnt in sorted(all_max.items(), key=lambda x: -x[1]):
        print(f"    {subj}: {cnt}节")

# ============================================================
# 7. 典型教师一周课分布
# ============================================================
print("\n" + "=" * 120)
print("【7】典型教师每周课时分布")
print("=" * 120)

# 先收集所有教师及其出现位置
teacher_schedule = defaultdict(list)  # teacher -> [(day, row, col)]

for day_name, start_col, end_col in day_configs:
    for row_num in all_class_rows:
        for c in range(start_col, end_col + 1):
            val = ws.cell(row=row_num, column=c).value
            if val and isinstance(val, str):
                # 提取教师名（最后1-3个字）
                teacher = None
                known_subjects = [
                    '语文', '数学', '英语', '物理', '化学', '生物',
                    '政治', '历史', '地理', '体育', '通用'
                ]
                for subj in known_subjects:
                    if val.startswith(subj):
                        teacher = val[len(subj):]
                        break
                if teacher is None and val not in ['单体双通', '双体单通', '班  会']:
                    teacher = val  # 整个就是名字
                
                if teacher:
                    teacher_schedule[teacher].append((day_name, row_num, c))

# 选择典型教师：出现次数最多的
top_teachers = sorted(teacher_schedule.items(), key=lambda x: -len(x[1]))[:15]

print(f"\n{'教师':>6s} | {'总课时':>6s} | {'周一':>4s} | {'周二':>4s} | {'周三':>4s} | {'周四':>4s} | {'周五':>4s} | 分布详情")
print("-" * 100)

for teacher, schedule in top_teachers:
    day_count = defaultdict(int)
    day_detail = defaultdict(list)
    for day, row, col in schedule:
        day_count[day] += 1
        # 获取对应班级号
        class_num = ws.cell(row=4, column=col).value
        period = ws.cell(row=row, column=3).value
        if period is None:
            # 尝试星期四/五的节列
            for dc in [69, 91]:
                p = ws.cell(row=row, column=dc).value
                if p is not None:
                    period = p
                    break
        if class_num is None:
            # 走班
            day_detail[day].append(f"走班")
        else:
            day_detail[day].append(f"班{class_num}")
    
    total = len(schedule)
    mon = day_count.get('星期一', 0)
    tue = day_count.get('星期二', 0)
    wed = day_count.get('星期三', 0)
    thu = day_count.get('星期四', 0)
    fri = day_count.get('星期五', 0)
    
    detail_parts = []
    for d in ['星期一', '星期二', '星期三', '星期四', '星期五']:
        if day_count[d] > 0:
            detail_parts.append(f"{d}:{day_count[d]}节({','.join(day_detail[d])})")
    
    print(f"{teacher:>6s} | {total:>6d} | {mon:>4d} | {tue:>4d} | {wed:>4d} | {thu:>4d} | {fri:>4d} | {'; '.join(detail_parts)}")

# ============================================================
# 额外分析：单体双通/双体单通分布
# ============================================================
print("\n" + "=" * 120)
print("【额外】单体双通/双体单通 分布")
print("=" * 120)

for day_name, start_col, end_col in day_configs:
    single_double = []
    double_single = []
    for row_num in all_class_rows:
        for c in range(start_col, end_col + 1):
            val = ws.cell(row=row_num, column=c).value
            class_num = ws.cell(row=4, column=c).value
            period = ws.cell(row=row_num, column=3).value
            if val == '单体双通':
                single_double.append(f"班级{class_num}第{row_num}行(节{period})")
            elif val == '双体单通':
                double_single.append(f"班级{class_num}第{row_num}行(节{period})")
    print(f"\n{day_name}:")
    print(f"  单体双通: {', '.join(single_double) if single_double else '无'}")
    print(f"  双体单通: {', '.join(double_single) if double_single else '无'}")

# ============================================================
# 检查是否有两门课在一个单元格（单双周配对）
# ============================================================
print("\n" + "=" * 120)
print("【4补充】搜索可能的单双周配对模式")
print("=" * 120)

# 搜索包含数字、"/"、或异常长度的单元格
for day_name, start_col, end_col in day_configs:
    for row_num in all_class_rows:
        for c in range(start_col, end_col + 1):
            val = ws.cell(row=row_num, column=c).value
            if val and isinstance(val, str):
                if '/' in val or '\\' in val or len(val) > 8:
                    class_num = ws.cell(row=4, column=c).value
                    print(f"  {day_name} 班级{class_num} 行{row_num}: '{val}'")

# ============================================================
# 完整的每天班级课程表（选取班级1、11、20）
# ============================================================
print("\n" + "=" * 120)
print("【完整课程表】班级1、11、20的完整一周课程")
print("=" * 120)

for target_class in [1, 11, 20]:
    print(f"\n=== 班级{target_class} ===")
    print(f"{'':>12s} | {'星期一':>12s} | {'星期二':>12s} | {'星期三':>12s} | {'星期四':>12s} | {'星期五':>12s}")
    print("-" * 90)
    
    for period_label, rows in [("上午第1节", [5]), ("上午第2节", [6]), ("上午第3节", [7]), ("上午第4节", [8]),
                                 ("---午休---", []), 
                                 ("下午第5节", [11]), ("下午第6节", [12]), ("下午第7节(班会)", [13])]:
        if not rows:
            print(f"{'午休':>12s} | {'':>12s} | {'':>12s} | {'':>12s} | {'':>12s} | {'':>12s}")
            continue
        
        row_num = rows[0]
        cells = []
        for day_name, start_col, end_col in day_configs:
            # 找到班级对应的列
            found = False
            for c in range(start_col, end_col + 1):
                h4 = ws.cell(row=4, column=c).value
                if h4 is not None and str(h4).strip() == str(target_class):
                    val = ws.cell(row=row_num, column=c).value
                    cells.append(str(val) if val else "")
                    found = True
                    break
            if not found:
                cells.append("")
        
        print(f"{period_label:>12s} | {cells[0]:>12s} | {cells[1]:>12s} | {cells[2]:>12s} | {cells[3]:>12s} | {cells[4]:>12s}")

# ============================================================
# 每天课时数量汇总
# ============================================================
print("\n" + "=" * 120)
print("【课时汇总】")
print("=" * 120)
print(f"上午: 4节课 (第1-4节)")
print(f"午休: 第9行（第4节和第5节之间）")
print(f"下午: 3节课 (第5-7节)，其中第7节为班会")
print(f"每天总课时: 7节 (6节正课 + 1节班会)")
print(f"班级数量: 20个（编号1-20）+ 走班列")
print(f"走班列位置: 每天最后一列（星期一=列24, 星期二=列45, 星期三=列66, 星期四=列90, 星期五=111）")

print("\n分析完成！")
