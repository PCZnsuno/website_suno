import openpyxl

filepath = r"C:\Users\sl315\.trae-cn\attachments\6a54eed2739a715a6232c351\aa043607-d6ba-4388-bcf0-66fa9b0662a7_901f0b19-b0ba-45df-a00b-c452d532293a_2025-2026学年度第一学期高二级教师工作安排.xlsx"

wb = openpyxl.load_workbook(filepath, data_only=True)

print(f"共有 {len(wb.sheetnames)} 个 sheet: {wb.sheetnames}\n")

for sheet_name in wb.sheetnames:
    ws = wb[sheet_name]
    print(f"{'='*80}")
    print(f"Sheet: [{sheet_name}]  行数={ws.max_row}  列数={ws.max_column}")
    print(f"{'='*80}")
    
    # 打印所有列标题
    headers = [ws.cell(row=1, column=c).value for c in range(1, ws.max_column + 1)]
    print(f"列标题: {headers}")
    
    # 找目标列的索引
    col_map = {}
    for idx, h in enumerate(headers):
        if h:
            h_clean = str(h).strip().replace('\n', '').replace(' ', '')
            col_map[h_clean] = idx + 1
    
    target_cols = ['姓名', '科目', '班级', '周课时', '周课时数']
    found_cols = {k: col_map.get(k) for k in target_cols if k in col_map}
    print(f"找到的目标列: {found_cols}")
    
    if '周课时' not in found_cols:
        # 尝试模糊匹配
        for h in col_map:
            if '周课时' in h or '课时' in h:
                found_cols[h] = col_map[h]
                print(f"  模糊匹配到 '课时' 列: '{h}' -> 第{col_map[h]}列")
    
    print(f"\n前20行数据（包含姓名/科目/班级/周课时相关列）：")
    print(f"行号\t", end="")
    for k in found_cols:
        print(f"{k}\t", end="")
    print()
    print("-" * 100)
    
    for row_idx in range(2, min(22, ws.max_row + 1)):
        print(f"{row_idx}\t", end="")
        for k, col_idx in found_cols.items():
            val = ws.cell(row=row_idx, column=col_idx).value
            if val is None:
                val = "(空)"
            print(f"{val}\t", end="")
        print()
    
    # 再打印完整的前5行（所有列），方便了解整体结构
    print(f"\n--- 前5行完整数据预览 ---")
    for row_idx in range(1, min(6, ws.max_row + 1)):
        row_data = [ws.cell(row=row_idx, column=c).value for c in range(1, ws.max_column + 1)]
        print(f"Row {row_idx}: {row_data}")
    
    print()

wb.close()
