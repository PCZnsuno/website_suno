import openpyxl

filepath = r"C:\Users\sl315\.trae-cn\attachments\6a54eed2739a715a6232c351\aa043607-d6ba-4388-bcf0-66fa9b0662a7_901f0b19-b0ba-45df-a00b-c452d532293a_2025-2026学年度第一学期高二级教师工作安排.xlsx"

wb = openpyxl.load_workbook(filepath, data_only=True)
ws = wb['Sheet1']

print("=" * 120)
print("完整数据预览（前30行，所有列）")
print("=" * 120)

for row_idx in range(1, min(31, ws.max_row + 1)):
    row_data = []
    for c in range(1, ws.max_column + 1):
        val = ws.cell(row=row_idx, column=c).value
        row_data.append(val)
    print(f"Row {row_idx:2d}: {row_data}")

print("\n\n")
print("=" * 120)
print("分析：左栏（A-G列）")
print("=" * 120)
print(f"{'行':>4s} | {'序号':>4s} | {'科目':>8s} | {'姓名':>6s} | {'简称':>4s} | {'任教班级':>8s} | {'上课':>4s} | {'备课':>4s}")
print("-" * 120)

for row_idx in range(4, ws.max_row + 1):
    fields = [ws.cell(row=row_idx, column=c).value for c in range(1, 8)]
    seq, subj, name, abbr, classes, shangke, beike = fields
    if seq is None and name is None:
        continue
    if name is None:
        name = "(合并单元格-同上)"
    print(f"{row_idx:4d} | {str(seq):>4s} | {str(subj):>8s} | {str(name):>6s} | {str(abbr):>4s} | {str(classes):>8s} | {str(shangke):>4s} | {str(beike):>4s}")

print("\n\n")
print("=" * 120)
print("分析：右栏（I-O列）")
print("=" * 120)
print(f"{'行':>4s} | {'序号':>4s} | {'科目':>8s} | {'姓名':>6s} | {'简称':>4s} | {'任教班级':>8s} | {'上课':>4s} | {'备课':>4s}")
print("-" * 120)

for row_idx in range(4, ws.max_row + 1):
    fields = [ws.cell(row=row_idx, column=c).value for c in range(9, 16)]
    seq, subj, name, abbr, classes, shangke, beike = fields
    if seq is None and name is None:
        continue
    if name is None:
        name = "(合并单元格-同上)"
    print(f"{row_idx:4d} | {str(seq):>4s} | {str(subj):>8s} | {str(name):>6s} | {str(abbr):>4s} | {str(classes):>8s} | {str(shangke):>4s} | {str(beike):>4s}")

print("\n\n")
print("=" * 120)
print("分析：班级-班主任列（P-Q列）")
print("=" * 120)
print(f"{'行':>4s} | {'班级':>4s} | {'班主任':>6s}")
print("-" * 60)
for row_idx in range(4, ws.max_row + 1):
    banji = ws.cell(row=row_idx, column=16).value
    head_teacher = ws.cell(row=row_idx, column=17).value
    if banji is not None or head_teacher is not None:
        print(f"{row_idx:4d} | {str(banji):>4s} | {str(head_teacher):>6s}")

wb.close()
