import openpyxl

filepath = r"C:\Users\sl315\.trae-cn\attachments\6a54eed2739a715a6232c351\aa043607-d6ba-4388-bcf0-66fa9b0662a7_901f0b19-b0ba-45df-a00b-c452d532293a_2025-2026学年度第一学期高二级教师工作安排.xlsx"

wb = openpyxl.load_workbook(filepath, data_only=True)
ws = wb['Sheet1']

print("=" * 100)
print("完整分析：'上课'列到底是教师总课时还是每班课时？")
print("=" * 100)

# 解析班级数
def count_classes(classes_val):
    if classes_val is None:
        return 0, True
    s = str(classes_val).strip()
    if '产假' in s or '退休' in s:
        return 0, True
    count = 0
    special = False
    parts = s.replace('、', ',').replace('，', ',').split(',')
    for p in parts:
        p = p.strip()
        if not p:
            continue
        if p.isdigit():
            count += 1
        elif '-' in p and not any(c in p for c in '走班合格性'):
            try:
                a, b = p.split('-')
                count += (int(b) - int(a) + 1)
            except:
                pass
        elif '走班' in p or '合格性' in p:
            count += 1
            special = True
        else:
            count += 1
    return count, special

# 收集所有数据
all_data = []

# 左栏 A-G: 科目(col2), 姓名(col3), 任教班级(col5), 上课(col6), 备课(col7)
current_subj = None
for row_idx in range(4, ws.max_row + 1):
    subj = ws.cell(row=row_idx, column=2).value
    name = ws.cell(row=row_idx, column=3).value
    classes = ws.cell(row=row_idx, column=5).value
    shangke = ws.cell(row=row_idx, column=6).value
    beike = ws.cell(row=row_idx, column=7).value
    if subj and isinstance(subj, str):
        current_subj = str(subj).strip()
    if name:
        cc, special = count_classes(classes)
        all_data.append({
            'panel': '左',
            'subject': current_subj or '',
            'name': str(name).strip(),
            'classes_raw': str(classes).strip() if classes else '',
            'class_count': cc,
            'shangke': shangke if shangke else 0,
            'beike': beike if beike else 0,
            'special': special
        })

# 右栏 I-O: 科目(col9), 姓名(col10), 任教班级(col12), 上课(col13), 备课(col14)
current_subj_r = None
for row_idx in range(4, ws.max_row + 1):
    subj = ws.cell(row=row_idx, column=9).value
    name = ws.cell(row=row_idx, column=10).value
    classes = ws.cell(row=row_idx, column=12).value
    shangke = ws.cell(row=row_idx, column=13).value
    beike = ws.cell(row=row_idx, column=14).value
    if subj and isinstance(subj, str):
        s = str(subj).strip()
        if any(c in s for c in '化学化学生物政治历史地理体育通用'):
            current_subj_r = s
    if name:
        cc, special = count_classes(classes)
        all_data.append({
            'panel': '右',
            'subject': current_subj_r or '',
            'name': str(name).strip(),
            'classes_raw': str(classes).strip() if classes else '',
            'class_count': cc,
            'shangke': shangke if shangke else 0,
            'beike': beike if beike else 0,
            'special': special
        })

# 提取科目简称
import re
def subj_short(s):
    for kw in ['语文', '数学', '英语', '物理', '化学', '生物', '政治', '历史', '地理', '体育', '通用']:
        if kw in s:
            return kw
    return s if s else '未知'

from collections import defaultdict
by_subj = defaultdict(list)
for d in all_data:
    by_subj[subj_short(d['subject'])].append(d)

print("\n\n")
for subj_key in ['语文', '数学', '英语', '物理', '化学', '生物', '政治', '历史', '地理', '体育', '通用']:
    items = by_subj.get(subj_key, [])
    if not items:
        continue
    normal = [i for i in items if not i['special'] and i['shangke'] > 0 and i['class_count'] > 0]
    print(f"\n{'='*80}")
    print(f"【{subj_key}】共 {len(items)} 条记录")
    print(f"{'姓名':<6s} {'任教班级':<22s} {'班数':>5s} {'上课':>6s} {'上课/班':>8s} {'备课':>6s}")
    print(f"{'-'*60}")
    for d in items:
        if d['special']:
            tag = ' [特殊]'
        else:
            tag = ''
        if d['class_count'] > 0 and not d['special']:
            ratio = f"{d['shangke']/d['class_count']:.1f}"
        else:
            ratio = '-'
        print(f"{d['name']:<6s} {d['classes_raw']:<22s} {d['class_count']:>5d} {d['shangke']:>6} {ratio:>8s} {d['beike']:>6}{tag}")
    if normal:
        ratios = [round(d['shangke']/d['class_count'], 1) for d in normal]
        from collections import Counter
        cnt = Counter(ratios)
        most_common = cnt.most_common(1)[0]
        print(f"  >>> 结论: 上课/班 ≈ {most_common[0]}（{most_common[1]}/{len(normal)}条记录一致）")

print("\n\n" + "=" * 100)
print("最终结论")
print("=" * 100)
print("""
"上课"列填写的是【每位教师的总周课时数】，而非每班课时数。

证据如下：
- 语文/数学/英语：每班 6 节/周。教 1 个班的老师上课=6，教 2 个班的老师上课=12。
- 物理：每班约 5 节/周。教 2 个班的老师上课=10~11。
- 化学/生物/政治/地理：每班约 4 节/周。教 2 个班的老师上课=8，教 3 个班的老师上课=12。
- 历史：每班 5 节/周。教 1 个班的老师上课=5，教 2 个班的老师上课=10。

如果"上课"是按每班课时填的，那么教多个班的老师数值会和教一个班的一样（都是每班课时数），
但实际数据显示教 N 个班的老师上课数就是教 1 个班的 N 倍，这是典型的教师总课时特征。
""")

wb.close()
