# -*- coding: utf-8 -*-
import openpyxl
from collections import defaultdict
import re

filepath = r"C:\Users\sl315\.trae-cn\attachments\6a54eed2739a715a6232c351\c8327b87-f461-4348-9873-d307a3cdecac_95b77871-fbe8-4cfa-87bd-c9865cc218fe_2526第一学期高二级课程表.xlsx"

wb = openpyxl.load_workbook(filepath, data_only=True)
ws = wb['Sheet1']

# ============================================================
# 表格结构映射 (经过验证)
# ============================================================
# 星期一: 班级1=D(4), 班级2=E(5), ..., 班级20=W(23), 走班=X(24)
# 星期二: 班级1=Y(25), 班级2=Z(26), ..., 班级20=AR(44), 走班=AS(45)
# 星期三: 班级1=AT(46), 班级2=AU(47), ..., 班级20=BM(65), 走班=BN(66)
# 星期四: 班级1=BR(70), 班级2=BS(71), ..., 班级20=CK(89), 走班=CL(90)
# 星期五: 班级1=CM(91), 班级2=CN(92), ..., 班级20=DF(110), 走班=DG(111)

class_columns = {}
# 星期一: D(4)->1, E(5)->2, ..., W(23)->20
for i in range(20):
    class_columns[('周一', i+1)] = 4 + i

# 星期二: Y(25)->1, Z(26)->2, ..., AR(44)->20
for i in range(20):
    class_columns[('周二', i+1)] = 25 + i

# 星期三: AT(46)->1, AU(47)->2, ..., BM(65)->20
for i in range(20):
    class_columns[('周三', i+1)] = 46 + i

# 星期四: BR(70)->1, BS(71)->2, ..., CK(89)->20
for i in range(20):
    class_columns[('周四', i+1)] = 70 + i

# 星期五: CM(91)->1, CN(92)->2, ..., DF(110)->20
for i in range(20):
    class_columns[('周五', i+1)] = 91 + i

# 走班列
zouban_columns = {
    '周一': 24,   # X
    '周二': 45,   # AS
    '周三': 66,   # BN
    '周四': 90,   # CL
    '周五': 111,  # DG
}

# 节数行映射 (上午4节 + 下午3节)
period_rows = {
    1: 5,   # 第1节 -> 行5
    2: 6,   # 第2节 -> 行6
    3: 7,   # 第3节 -> 行7
    4: 8,   # 第4节 -> 行8
    5: 11,  # 第5节 -> 行11
    6: 12,  # 第6节 -> 行12
    7: 13,  # 第7节 -> 行13
}

days = ['周一', '周二', '周三', '周四', '周五']

# 科目列表
SUBJECTS = {'语文', '数学', '英语', '物理', '化学', '生物', '政治', '历史', '地理', '体育', '音乐', '美术', '信息', '通用', '劳动', '心理'}

# ============================================================
# 解析课程数据
# ============================================================
def parse_course(value):
    """解析课程字符串，返回(科目, 教师简称)"""
    if value is None:
        return None, None
    val = str(value).strip()
    if not val or val in ('班  会', '班会'):
        return None, None
    if val in ('单体双通', '双体单通'):
        return val, val
    # 课程格式: 科目 + 教师简称
    for subj in sorted(SUBJECTS, key=len, reverse=True):  # 先匹配长的科目名
        if val.startswith(subj):
            teacher = val[len(subj):]
            if teacher:
                return subj, teacher
    return val, val

# 收集所有课程数据
teacher_stats = defaultdict(lambda: {
    'total': 0,
    'by_day': defaultdict(int),
    'by_period': defaultdict(list),
    'cells': [],
    'subjects': set()
})

class_stats = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))  # class_num -> day -> subject -> count
class_day_count = defaultdict(lambda: defaultdict(int))  # class_num -> day -> total

zouban_courses = []  # (day, period, subject, teacher, raw)
special_courses = []  # (day, period, class_num, type)
all_course_entries = []  # (day, period, class_num, subject, teacher, raw, is_zouban)

# 遍历所有课程单元格
for day in days:
    for period in range(1, 8):
        row = period_rows[period]
        
        # 常规课程 (班级1-20)
        for class_num in range(1, 21):
            col = class_columns[(day, class_num)]
            val = ws.cell(row=row, column=col).value
            if val is not None:
                subject, teacher = parse_course(val)
                if subject and teacher:
                    if subject in ('单体双通', '双体单通'):
                        special_courses.append((day, period, class_num, subject))
                    else:
                        all_course_entries.append((day, period, class_num, subject, teacher, str(val), False))
                        teacher_stats[teacher]['total'] += 1
                        teacher_stats[teacher]['by_day'][day] += 1
                        teacher_stats[teacher]['by_period'][day].append(period)
                        teacher_stats[teacher]['cells'].append(f"{day}第{period}节高二({class_num})班")
                        teacher_stats[teacher]['subjects'].add(subject)
                        class_stats[class_num][day][subject] += 1
                        class_day_count[class_num][day] += 1
        
        # 走班课程
        zcol = zouban_columns[day]
        val = ws.cell(row=row, column=zcol).value
        if val is not None:
            subject, teacher = parse_course(val)
            if subject and teacher:
                zouban_courses.append((day, period, subject, teacher, str(val)))
                if subject not in ('单体双通', '双体单通'):
                    all_course_entries.append((day, period, 0, subject, teacher, str(val), True))
                    teacher_stats[teacher]['total'] += 1
                    teacher_stats[teacher]['by_day'][day] += 1
                    teacher_stats[teacher]['by_period'][day].append(period)
                    teacher_stats[teacher]['cells'].append(f"{day}第{period}节走班")
                    teacher_stats[teacher]['subjects'].add(subject)

# ============================================================
# 输出分析结果
# ============================================================
output_lines = []

def add(line=''):
    output_lines.append(line)

def section(title):
    add(f"\n{'='*80}")
    add(f"  {title}")
    add(f"{'='*80}")

# ---- 任务1: 教师统计 ----
section("一、教师统计")

add("\n【1.1】每个教师出现的总次数（总课时）— 按课时降序排列")
add(f"{'教师':<8} {'总课时':>6}  {'涉及科目':<30}  每天分布")
add('-' * 100)
for teacher in sorted(teacher_stats.keys(), key=lambda t: teacher_stats[t]['total'], reverse=True):
    s = teacher_stats[teacher]
    subjects_str = '/'.join(sorted(s['subjects']))
    day_detail = ', '.join([f"{d}:{s['by_day'][d]}节" for d in days if s['by_day'][d] > 0])
    add(f"{teacher:<8} {s['total']:>6}  {subjects_str:<30}  {day_detail}")

add("\n【1.2】每个教师在每天（周一~周五）出现的次数")
add(f"{'教师':<8} {'周一':>4} {'周二':>4} {'周三':>4} {'周四':>4} {'周五':>4} {'合计':>6}")
add('-' * 50)
for teacher in sorted(teacher_stats.keys(), key=lambda t: teacher_stats[t]['total'], reverse=True):
    s = teacher_stats[teacher]
    line = f"{teacher:<8}"
    for d in days:
        line += f" {s['by_day'][d]:>4}"
    line += f" {s['total']:>6}"
    add(line)

add("\n【1.3】每个教师在每天的第几节课出现")
add(f"{'教师':<8}  {'周一':<15} {'周二':<15} {'周三':<15} {'周四':<15} {'周五':<15}")
add('-' * 90)
for teacher in sorted(teacher_stats.keys(), key=lambda t: teacher_stats[t]['total'], reverse=True):
    s = teacher_stats[teacher]
    line = f"{teacher:<8} "
    for d in days:
        periods = sorted(s['by_period'].get(d, []))
        if periods:
            line += f" {','.join(map(str, periods)):<14}"
        else:
            line += f" {'--':<14}"
    add(line)

# ---- 任务2: 班级统计 ----
section("二、班级统计")

add("\n【2.1】每班每天每科出现的次数")
for class_num in range(1, 21):
    add(f"\n--- 高二({class_num})班 ---")
    add(f"  {'星期':<6}  课程分布")
    add(f"  {'-'*60}")
    for day in days:
        subjects = class_stats[class_num][day]
        if subjects:
            detail = ', '.join([f"{s}x{c}" for s, c in sorted(subjects.items())])
            total = class_day_count[class_num][day]
            add(f"  {day:<6}  {detail} (共{total}节)")
        else:
            add(f"  {day:<6}  (无课程)")

add("\n【2.2】每班每天总共几节课")
add(f"{'班级':<12} {'周一':>4} {'周二':>4} {'周三':>4} {'周四':>4} {'周五':>4} {'合计':>6}")
add('-' * 50)
for class_num in range(1, 21):
    line = f"高二({class_num:>2})班"
    total = 0
    for d in days:
        cnt = class_day_count[class_num][d]
        line += f" {cnt:>4}"
        total += cnt
    line += f" {total:>6}"
    add(line)

add("\n【2.3】检查是否有某班某天某科出现3次及以上的异常情况")
found_triple = False
for class_num in range(1, 21):
    for day in days:
        for subject, count in class_stats[class_num][day].items():
            if count >= 3:
                add(f"  !!! 异常: 高二({class_num})班 {day} {subject} 出现 {count} 次 !!!")
                found_triple = True
if not found_triple:
    add("  未发现某班某天某科出现3次及以上的情况。所有班级均正常。")

# ---- 任务3: 英语教师对比 ----
section("三、英语教师对比")

# 从原始数据中找出所有英语教师
english_teacher_set = set()
for day in days:
    for period in range(1, 8):
        row = period_rows[period]
        for class_num in range(1, 21):
            col = class_columns[(day, class_num)]
            val = str(ws.cell(row=row, column=col).value or '')
            if val.startswith('英语'):
                english_teacher_set.add(val[2:])
        zcol = zouban_columns[day]
        val = str(ws.cell(row=row, column=zcol).value or '')
        if val.startswith('英语'):
            english_teacher_set.add(val[2:])

add(f"\n所有英语教师({len(english_teacher_set)}位): {', '.join(sorted(english_teacher_set))}")

add("\n【3.1】英语教师'艺'的详细统计")
if '艺' in teacher_stats:
    yi = teacher_stats['艺']
    add(f"  英语教师'艺'一共出现在 {yi['total']} 个单元格中")
    add(f"\n  每天分布:")
    for d in days:
        periods = sorted(yi['by_period'].get(d, []))
        if periods:
            add(f"    {d}: {len(periods)}节, 分别是第{','.join(map(str, periods))}节")
        else:
            add(f"    {d}: 0节 (当天无课)")
    add(f"\n  所有出现位置:")
    for cell in yi['cells']:
        add(f"    - {cell}")
else:
    add("  未找到英语教师'艺'的数据。")

add("\n【3.2】所有英语教师对比总表")
add(f"{'教师':<6} {'总课时':>6} {'周一':>4} {'周二':>4} {'周三':>4} {'周四':>4} {'周五':>4}")
add('-' * 50)
for t in sorted(english_teacher_set):
    if t in teacher_stats:
        s = teacher_stats[t]
        line = f"{t:<6} {s['total']:>6}"
        for d in days:
            line += f" {s['by_day'][d]:>4}"
        add(line)

add("\n【3.3】英语教师与其他科目的兼任情况")
for t in sorted(english_teacher_set):
    if t in teacher_stats:
        subjects = teacher_stats[t]['subjects']
        non_english = [s for s in subjects if s != '英语']
        if non_english:
            add(f"  英语教师'{t}'还兼任: {', '.join(non_english)}")
        else:
            add(f"  英语教师'{t}'只教英语")

# ---- 任务4: 走班列分析 ----
section("四、走班列分析")

add("\n【4.1】走班列里的全部内容")
add(f"  {'星期':<6} {'节次':<8} {'原始内容':<15} {'科目':<8} {'教师':<6}")
add(f"  {'-'*50}")
zouban_teachers = set()
zouban_subjects = set()
for day, period, subject, teacher, raw in zouban_courses:
    add(f"  {day:<6} 第{period}节    {raw:<15} {subject:<8} {teacher:<6}")
    zouban_teachers.add(teacher)
    zouban_subjects.add(subject)

add(f"\n  走班列涉及的教师: {', '.join(sorted(zouban_teachers))}")
add(f"  走班列涉及的科目: {', '.join(sorted(zouban_subjects))}")

add("\n【4.2】走班课与常规课是否有重叠（同一教师同一时段）")
conflicts = []
for day, period, subject, teacher, raw in zouban_courses:
    if subject in ('单体双通', '双体单通'):
        continue
    row = period_rows[period]
    for class_num in range(1, 21):
        col = class_columns[(day, class_num)]
        val = str(ws.cell(row=row, column=col).value or '')
        _, cteacher = parse_course(val)
        if cteacher == teacher:
            conflicts.append((day, period, teacher, class_num, subject))

if conflicts:
    add("  发现以下重叠（同一教师同一时段既在常规课又在走班）:")
    for day, period, teacher, class_num, subj in conflicts:
        add(f"    {day}第{period}节: 教师'{teacher}' 同时出现在常规课(高二{class_num}班)和走班({subj})")
else:
    add("  未发现同一教师同一时段既在常规又在走班的冲突。走班安排合理。")

# ---- 任务5: 单体双通/双体单通分析 ----
section("五、'单体双通'和'双体单通'分析")

add("\n【说明】根据备注:")
add("  体育课和通用技术课采用单体双通和双体单通方式上课。")
add("  - '单体双通': 一个教师同时给两个班级上课（如体育课合班上）")
add("  - '双体单通': 两个教师分别各带一个班级上课（如体育课分班上）")

add("\n【5.1】所有单体双通/双体单通的分布")
add(f"  {'星期':<6} {'节次':<8} {'班级':<12} {'类型':<10}")
add(f"  {'-'*45}")
count_sd = 0  # 单体双通
count_ds = 0  # 双体单通
for day, period, class_num, stype in special_courses:
    add(f"  {day:<6} 第{period}节    高二({class_num:>2})班  {stype}")
    if stype == '单体双通':
        count_sd += 1
    else:
        count_ds += 1

add(f"\n  总计:")
add(f"    单体双通: {count_sd} 次")
add(f"    双体单通: {count_ds} 次")
add(f"    合计: {count_sd + count_ds} 次")

add("\n  按天统计:")
for day in days:
    sd = sum(1 for d, p, c, t in special_courses if d == day and t == '单体双通')
    ds = sum(1 for d, p, c, t in special_courses if d == day and t == '双体单通')
    add(f"    {day}: 单体双通={sd}, 双体单通={ds}")

# 按节次统计
add("\n  按节次统计:")
for period in range(1, 8):
    sd = sum(1 for d, p, c, t in special_courses if p == period and t == '单体双通')
    ds = sum(1 for d, p, c, t in special_courses if p == period and t == '双体单通')
    if sd > 0 or ds > 0:
        add(f"    第{period}节: 单体双通={sd}, 双体单通={ds}")

# 分析配对
add("\n【5.2】配对分析（同一时段出现的班级对）")
# 找出同一时段同一类型的班级配对
sd_by_slot = defaultdict(list)
ds_by_slot = defaultdict(list)
for day, period, class_num, stype in special_courses:
    key = (day, period)
    if stype == '单体双通':
        sd_by_slot[key].append(class_num)
    else:
        ds_by_slot[key].append(class_num)

add("  单体双通配对（一个教师同时带两个班）:")
for key, classes in sorted(sd_by_slot.items()):
    if len(classes) >= 2:
        add(f"    {key[0]}第{key[1]}节: 班级 {', '.join([str(c) for c in classes])}")
    else:
        add(f"    {key[0]}第{key[1]}节: 班级 {classes[0]} (单个)")

add("  双体单通配对（两个教师各带一个班）:")
for key, classes in sorted(ds_by_slot.items()):
    if len(classes) >= 2:
        add(f"    {key[0]}第{key[1]}节: 班级 {', '.join([str(c) for c in classes])}")
    else:
        add(f"    {key[0]}第{key[1]}节: 班级 {classes[0]} (单个)")

# ---- 任务6: 完整数据表格 ----
section("六、每行每列的完整数据（有数据的列）")

add("\n【表格结构说明】")
add("  标题行: 行1 (棉湖中学2025-2026学年度第一学期高二级课程表)")
add("  星期头: 行3 (星期一~星期五)")
add("  节数头: 行4 (班级1-20编号 + 走班)")
add("  上午课: 行5-8 (第1-4节)")
add("  午休: 行9 (空行)")
add("  下午头: 行10 (班级编号)")
add("  下午课: 行11-13 (第5-7节)")
add("  备注: 行14")

# 输出每天的完整课程表
for day in days:
    add(f"\n{'='*120}")
    add(f"  {day} 完整课程表")
    add(f"{'='*120}")
    
    # 表头
    header = f"{'节次':<8}"
    for class_num in range(1, 21):
        header += f" {'C' + str(class_num):<8}"
    header += f" {'走班':<12}"
    add(header)
    add('-' * 120)
    
    for period in range(1, 8):
        row = period_rows[period]
        period_label = "上午" if period <= 4 else "下午"
        line = f"第{period}节({period_label})"
        
        for class_num in range(1, 21):
            col = class_columns[(day, class_num)]
            val = ws.cell(row=row, column=col).value
            if val is not None:
                line += f" {str(val):<8}"
            else:
                line += f" {'--':<8}"
        
        # 走班
        zcol = zouban_columns[day]
        zval = ws.cell(row=row, column=zcol).value
        if zval is not None:
            line += f" {str(zval):<12}"
        else:
            line += f" {'--':<12}"
        add(line)

# ---- 补充统计 ----
section("七、补充统计信息")

add(f"\n总共统计的课程单元格数: {len(all_course_entries)}")
add(f"  其中常规课程: {sum(1 for e in all_course_entries if not e[6])}")
add(f"  其中走班课程: {sum(1 for e in all_course_entries if e[6])}")
add(f"  特殊课程(单体双通/双体单通): {len(special_courses)}")
add(f"  走班列中的特殊项: {sum(1 for d,p,s,t,r in zouban_courses if s in ('单体双通','双体单通'))}")

add(f"\n涉及的教师总数: {len(teacher_stats)}")
add(f"涉及的科目: {', '.join(sorted(set(s for t in teacher_stats.values() for s in t['subjects'])))}")

# ============================================================
# 输出
# ============================================================
output_text = '\n'.join(output_lines)
print(output_text)

# 保存到文件
output_path = r'C:\Users\sl315\.trae-cn\work\6a54eed2739a715a6232c351\schedule_analysis_output.txt'
with open(output_path, 'w', encoding='utf-8') as f:
    f.write(output_text)

print(f"\n\n分析完成！结果已保存到: {output_path}")
