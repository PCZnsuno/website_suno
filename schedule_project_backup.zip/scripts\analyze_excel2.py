# -*- coding: utf-8 -*-
import openpyxl
from collections import defaultdict, Counter
import re

FILE_PATH = r"c:\Users\sl315\.trae-cn\attachments\6a54eed2739a715a6232c351\c8327b87-f461-4348-9873-d307a3cdecac_95b77871-fbe8-4cfa-87bd-c9865cc218fe_2526第一学期高二级课程表.xlsx"

def col_letter(n):
    """列号转字母"""
    result = ""
    while n > 0:
        n, remainder = divmod(n - 1, 26)
        result = chr(65 + remainder) + result
    return result

wb = openpyxl.load_workbook(FILE_PATH, data_only=True)
ws = wb['Sheet1']

# ============================================================
# 1. 找出实际有数据的最大列
# ============================================================
print("=" * 120)
print("【关键行的完整数据】")
print("=" * 120)

# 先找实际有数据的列范围
max_data_col = 0
for r in range(1, ws.max_row + 1):
    for c in range(ws.max_column, 0, -1):
        if ws.cell(row=r, column=c).value is not None:
            if c > max_data_col:
                max_data_col = c
            break

print(f"\n实际最大数据列: {max_data_col}")

# 打印关键行的完整内容
key_rows = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 23, 24, 25]
for r in key_rows:
    if r <= ws.max_row:
        print(f"\n--- 第{r}行 全部非空单元格 ---")
        non_empty = []
        for c in range(1, max_data_col + 1):
            val = ws.cell(row=r, column=c).value
            if val is not None:
                display = str(val).replace('\n', '[BR]').replace('\r', '[CR]')
                non_empty.append(f"  列{c}({col_letter(c)}): '{display}'")
        for item in non_empty:
            print(item)
        if not non_empty:
            print("  (全空)")

# ============================================================
# 合并单元格详细信息
# ============================================================
print("\n" + "=" * 120)
print("【合并单元格完整列表】")
print("=" * 120)

for merge_range in ws.merged_cells.ranges:
    min_r, max_r = merge_range.min_row, merge_range.max_row
    min_c, max_c = merge_range.min_col, merge_range.max_col
    val = ws.cell(row=min_r, column=min_c).value
    val_display = str(val)[:80] if val else "None"
    print(f"  {col_letter(min_c)}{min_r}:{col_letter(max_c)}{max_r} "
          f"(行{min_r}-{max_r}, 列{min_c}-{max_c}, "
          f"大小={max_r-min_r+1}行x{max_c-min_c+1}列) "
          f"值='{val_display}'")

# ============================================================
# 打印每个工作日区域的完整数据
# ============================================================
print("\n" + "=" * 120)
print("【每天区域的完整数据（行3-13的所有列）】")
print("=" * 120)

# 打印行3到行13的所有列
print(f"\n列号对照表 (列号 -> Excel列字母):")
for c in range(1, max_data_col + 1):
    l = col_letter(c)
    # 打印有内容的列
    for r in [3, 4, 5, 10]:
        val = ws.cell(row=r, column=c).value
        if val is not None:
            print(f"  列{c:3d}({l:3s}): 行3='{ws.cell(row=3,column=c).value}', "
                  f"行4='{ws.cell(row=4,column=c).value}', "
                  f"行5='{ws.cell(row=5,column=c).value}', "
                  f"行10='{ws.cell(row=10,column=c).value}'")
            break

# ============================================================
# 逐日分析
# ============================================================
print("\n" + "=" * 120)
print("【逐日完整数据表格】")
print("=" * 120)

# 从合并单元格获取每天的列范围
day_ranges = []
for merge_range in ws.merged_cells.ranges:
    min_r, max_r = merge_range.min_row, merge_range.max_row
    min_c, max_c = merge_range.min_col, merge_range.max_col
    val = ws.cell(row=min_r, column=min_c).value
    if val and isinstance(val, str) and '星期' in val and min_r == 3:
        day_ranges.append((val, min_c, max_c))

day_ranges.sort(key=lambda x: x[1])

for day_name, start_col, end_col in day_ranges:
    print(f"\n{'='*80}")
    print(f"{day_name} (列{start_col}={col_letter(start_col)} 到 列{end_col}={col_letter(end_col)}, 共{end_col-start_col+1}列)")
    print(f"{'='*80}")
    
    # 打印表头（行4的班级编号）
    header = f"{'行':>4s} |"
    for c in range(start_col, end_col + 1):
        val = ws.cell(row=4, column=c).value
        if val is None:
            val = ws.cell(row=10, column=c).value  # 尝试行10
        display = str(val) if val else ""
        header += f" {display:>6s} |"
    print(header)
    print("-" * len(header))
    
    # 打印数据行
    data_rows = [
        (5, "上午第1节"), (6, "上午第2节"), (7, "上午第3节"), (8, "上午第4节"),
        (9, "(午休)"),
        (11, "下午第5节"), (12, "下午第6节"), (13, "下午第7节(班会)")
    ]
    
    for row_num, label in data_rows:
        row_str = f"{row_num:4d} |"
        for c in range(start_col, end_col + 1):
            val = ws.cell(row=row_num, column=c).value
            if val is None:
                display = ""
            else:
                display = str(val).replace('\n', '/').replace('\r', '')
                if len(display) > 7:
                    display = display[:6] + "."
            row_str += f" {display:>6s} |"
        print(f"{row_str}  <- {label}")

# ============================================================
# 每个班级的课程统计（以星期一的班级为例）
# ============================================================
print("\n" + "=" * 120)
print("【课程统计 - 每天每班每科出现次数（选取前5个班作为示例）】")
print("=" * 120)

for day_name, start_col, end_col in day_ranges:
    print(f"\n--- {day_name} ---")
    # 第一个列通常是"节"标记，跳过
    class_cols = []
    for c in range(start_col, end_col + 1):
        header_val = ws.cell(row=4, column=c).value
        if header_val is not None and str(header_val).strip() not in ['节', '走班', '']:
            class_cols.append((c, str(header_val).strip()))
    
    # 只显示前5个班
    for col_idx, class_name in class_cols[:5]:
        daily_subjects = []
        for row_num in [5, 6, 7, 8, 11, 12]:
            val = ws.cell(row=row_num, column=col_idx).value
            if val:
                daily_subjects.append(str(val))
        
        # 统计科目
        subject_counter = Counter()
        for s in daily_subjects:
            # 提取科目名（去掉教师名，一般最后1-2个字是教师名）
            subject_counter[s] += 1
        
        print(f"  班级{class_name}(列{col_idx}): {daily_subjects}")

# ============================================================
# 搜索"走班"列
# ============================================================
print("\n" + "=" * 120)
print("【走班列详细内容】")
print("=" * 120)

for r in range(1, ws.max_row + 1):
    for c in range(1, max_data_col + 1):
        val = ws.cell(row=r, column=c).value
        if val and '走班' in str(val):
            print(f"  单元格({r},{c}) = '{val}'")

# 找到每个走班列的位置
print("\n走班列数据:")
for day_name, start_col, end_col in day_ranges:
    for c in range(start_col, end_col + 1):
        val4 = ws.cell(row=4, column=c).value
        if val4 and '走班' in str(val4):
            print(f"\n  {day_name} 走班列 = 列{c}({col_letter(c)})")
            for row_num in [5, 6, 7, 8, 11, 12, 13]:
                val = ws.cell(row=row_num, column=c).value
                print(f"    行{row_num}: {val}")

# ============================================================
# 行23-25的数据
# ============================================================
print("\n" + "=" * 120)
print("【行23-25数据】")
print("=" * 120)
for r in [23, 24, 25]:
    print(f"\n--- 行{r} ---")
    for c in range(1, max_data_col + 1):
        val = ws.cell(row=r, column=c).value
        if val is not None:
            print(f"  列{c}({col_letter(c)}): '{val}'")

# ============================================================
# 单元格原始值检查 - 随机抽样10个课程单元格
# ============================================================
print("\n" + "=" * 120)
print("【单元格格式抽样检查（repr展示）】")
print("=" * 120)

samples = [(5,4), (5,5), (6,4), (7,4), (7,7), (8,5), (11,4), (12,4), (13,4), (5,24)]
for r, c in samples:
    val = ws.cell(row=r, column=c).value
    print(f"  单元格({r},{c}) = {repr(val)}")

print("\n分析完成！")
